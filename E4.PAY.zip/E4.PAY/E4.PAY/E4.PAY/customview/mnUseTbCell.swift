//
//  mnUseTbCell.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit

class mnUseTbCell: UITableViewCell {

    @IBOutlet weak var regDt : UILabel?
    @IBOutlet weak var gdNm : UILabel?
    @IBOutlet weak var payAmt : UILabel?
    @IBOutlet weak var mnCd : UILabel?

}
