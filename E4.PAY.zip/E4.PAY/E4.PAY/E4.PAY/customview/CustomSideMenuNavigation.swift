//
//  CustomSidebarMenu.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/11.
//
import UIKit
import SideMenu

class CustomSideMenuNavigation: SideMenuNavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.menuWidth = self.view.frame.width * 0.7
        
        self.presentationStyle = .menuSlideIn



    }
    
}
