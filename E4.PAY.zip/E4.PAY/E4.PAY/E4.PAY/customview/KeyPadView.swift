//
//  KeyPadCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/09.
//

import UIKit


protocol SecretKeyDelegate : AnyObject {
    func outputData (Str : String , inputIdx : Int)
}



extension UIView {
    func loadViewFromNib(nib: String) -> UIView? {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: nib, bundle: bundle)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
    

    
}



public class KeypadView : UIView {
    
    //태그갑 1 = 6자리 , 2 = 자리 , 3 = 13자리 , 4 제한없음
 
    weak var delegate : SecretKeyDelegate?
    var idx : Int = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        xibSetup()
    }
    
    
    func xibSetup() {
        guard let view = loadViewFromNib(nib: "Keypad") else { return }
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
    @IBAction func prsBtn(_ sender: UIButton) {
        var data = sender.titleLabel?.text
        
        if(self.tag == 1) {
            
            if (self.idx < 6 || data == "초기화" || data == nil) {
                
                if (data == nil && self.idx > 0 ) {
                    data = "back"
                    self.idx -= 1
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                if data == "초기화" {
                    self.idx = 0
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                
                if(data != nil) {
                    
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    self.idx += 1
                }
                
            }else {
                return
            }
        } else if (self.tag == 2){
            
            if (self.idx < 4 || data == "초기화" || data == nil) {
                
                if (data == nil && self.idx > 0 ) {
                    data = "back"
                    self.idx -= 1
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                if data == "초기화" {
                    self.idx = 0
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                
                if(data != nil) {
                    
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    self.idx += 1
                }
                
            }
            
        }
        
        else if (self.tag == 3){
            
            if (self.idx < 13 || data == "초기화" || data == nil) {
                
                if (data == nil && self.idx > 0 ) {
                    data = "back"
                    self.idx -= 1
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                if data == "초기화" {
                    self.idx = 0
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                
                if(data != nil) {
                    
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    self.idx += 1
                }
                
            }
            
        }
        
        else if (self.tag == 4){
        
                
                if (data == nil && self.idx > 0 ) {
                    data = "back"
                    self.idx -= 1
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                if data == "초기화" {
                    self.idx = 0
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    return
                }
                
                if(data != nil) {
                    
                    delegate?.outputData(Str: data! , inputIdx : self.idx)
                    self.idx += 1
                }
                
            
        }
        
    }
    
    
    
}


class SecretInput : UIView {
    
    
    @IBOutlet weak var sLabel1: UILabel!
    @IBOutlet weak var sLabel2: UILabel!
    @IBOutlet weak var sLabel3: UILabel!
    @IBOutlet weak var sLabel4: UILabel!
    @IBOutlet weak var sLabel5: UILabel!
    @IBOutlet weak var sLabel6: UILabel!
    
    var labelList : [UILabel] = []

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()

    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        print("coder: aDecoder")
        xibSetup()
        labelList.append(sLabel1)
        labelList.append(sLabel2)
        labelList.append(sLabel3)
        labelList.append(sLabel4)
        labelList.append(sLabel5)
        labelList.append(sLabel6)
        
    }
    
    
    func xibSetup() {
        guard let view = loadViewFromNib(nib: "SecretInput") else { return }
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
}




class CardSecret : UIView {
    
    
    @IBOutlet weak var sLabel1: UILabel!
    @IBOutlet weak var sLabel2: UILabel!
    @IBOutlet weak var sLabel3: UILabel!
    @IBOutlet weak var sLabel4: UILabel!
    
    var labelList : [UILabel] = []

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()

    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        print("coder: aDecoder")
        xibSetup()
        labelList.append(sLabel1)
        labelList.append(sLabel2)
        labelList.append(sLabel3)
        labelList.append(sLabel4)
        
    }
    
    
    func xibSetup() {
        guard let view = loadViewFromNib(nib: "CardSecret") else { return }
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
}



class RegiNum : UIView {
    
    
    @IBOutlet weak var sLabel1: UILabel!
    @IBOutlet weak var sLabel2: UILabel!
    @IBOutlet weak var sLabel3: UILabel!
    @IBOutlet weak var sLabel4: UILabel!
    @IBOutlet weak var sLabel5: UILabel!
    @IBOutlet weak var sLabel6: UILabel!
    @IBOutlet weak var sLabel7: UILabel!
    @IBOutlet weak var sLabel8: UILabel!
    @IBOutlet weak var sLabel9: UILabel!
    @IBOutlet weak var sLabel10: UILabel!
    @IBOutlet weak var sLabel11: UILabel!
    @IBOutlet weak var sLabel12: UILabel!
    @IBOutlet weak var sLabel13: UILabel!
    var labelList : [UILabel] = []

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()

    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        print("coder: aDecoder")
        xibSetup()
        labelList.append(sLabel1)
        labelList.append(sLabel2)
        labelList.append(sLabel3)
        labelList.append(sLabel4)
        labelList.append(sLabel5)
        labelList.append(sLabel6)
        labelList.append(sLabel7)
        labelList.append(sLabel8)
        labelList.append(sLabel9)
        labelList.append(sLabel10)
        labelList.append(sLabel11)
        labelList.append(sLabel12)
        labelList.append(sLabel13)
        
    }
    
    
    func xibSetup() {
        guard let view = loadViewFromNib(nib: "RegiNum") else { return }
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
}
