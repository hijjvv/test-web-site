//
//  cmPopUp.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

protocol CmPopUpProtocol : AnyObject {
    func clickYes()
    func clickNo()
    func clickOk()
}
import UIKit

class CmPopUp: UIView {

    weak var delegate : CmPopUpProtocol?
    
    @IBOutlet weak var popUpNm: UILabel!
    
    @IBOutlet weak var popUpCont: UITextView!
    
    @IBOutlet weak var noBtn: UIButton!
    
    @IBOutlet weak var okBtn: UIButton!
    
    @IBOutlet weak var yesBtn: UIButton!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        xibSetup()
    }
    
    
    func xibSetup() {
        guard let view = loadViewFromNib(nib: "CmPopUp") else { return }
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
    @IBAction func clickYesEv(_ sender: Any) {
        self.delegate?.clickYes()
    }
    
    
    @IBAction func clickOkEv(_ sender: Any) {
        self.delegate?.clickOk()
    }
    
    @IBAction func clickNoEv(_ sender: Any) {
        self.delegate?.clickNo()
    }
    
    
    func commonPopUp(vc : UIViewController , cmPopUp : CmPopUp , head : String , content : String , logicCd : String){
      
        if(logicCd == "1"){
            
            cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
            cmPopUp.layer.cornerRadius = 10
            cmPopUp.layer.masksToBounds = true
            cmPopUp.popUpNm.text = head
            cmPopUp.popUpCont.text = content
            cmPopUp.yesBtn.isHidden = true
            cmPopUp.noBtn.isHidden = true
            cmPopUp.okBtn.isHidden = false
            cmPopUp.center = vc.view.center
            
            let topBorder = CALayer()
            topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.okBtn.frame.size.width, height: 0.5)
            topBorder.backgroundColor = UIColor.gray.cgColor
            cmPopUp.okBtn.layer.addSublayer(topBorder)
        }
        
        if(logicCd == "2"){
            
            cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
            cmPopUp.layer.cornerRadius = 10
            cmPopUp.layer.masksToBounds = true
            cmPopUp.popUpNm.text = head
            cmPopUp.popUpCont.text = content
            cmPopUp.yesBtn.isHidden = false
            cmPopUp.noBtn.isHidden = false
            cmPopUp.okBtn.isHidden = true
            cmPopUp.center = vc.view.center
            
            let topBorder = CALayer()
            topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.yesBtn.frame.size.width, height: 0.5)
            topBorder.backgroundColor = UIColor.gray.cgColor
            cmPopUp.noBtn.layer.addSublayer(topBorder)
            
            let topBorder2 = CALayer()
            topBorder2.frame = CGRect(x: 0, y: 0, width: cmPopUp.noBtn.frame.size.width, height: 0.5)
            topBorder2.backgroundColor = UIColor.gray.cgColor
            cmPopUp.yesBtn.layer.addSublayer(topBorder2)
        }
        
        //

        
        
        let darkBackgroundView = UIView(frame: vc.view.bounds)
        darkBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        darkBackgroundView.alpha = 0
        darkBackgroundView.tag = 123
        vc.view.addSubview(darkBackgroundView)
        
        
        // 팝업을 띄우기 위한 애니메이션
        cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        cmPopUp.alpha = 0
        vc.view.addSubview(cmPopUp)
        
        UIView.animate(withDuration: 0.3) {
            darkBackgroundView.alpha = 1
            cmPopUp.alpha = 1
            cmPopUp.transform = CGAffineTransform.identity
            
        }
    }
    
    
    @objc func commonHidePopUp(vc : UIViewController , cmPopUp : CmPopUp) {
           // 팝업이 사라질 때 배경 어둡게 처리 해제
        if let darkBackgroundView = vc.view.viewWithTag(123){
               UIView.animate(withDuration: 0.3, animations: {
                   darkBackgroundView.alpha = 0
               }) { (finished) in
                   if finished {
                       darkBackgroundView.removeFromSuperview()
                      
                   }
               }
           }

           // 팝업을 사라지게 하는 애니메이션
           UIView.animate(withDuration: 0.3, animations: {
               cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
               cmPopUp.alpha = 0
           }) { (finished) in
               if finished {
                   cmPopUp.removeFromSuperview()
                   cmPopUp.transform = CGAffineTransform.identity

               }
           }
       }
    
    

}





