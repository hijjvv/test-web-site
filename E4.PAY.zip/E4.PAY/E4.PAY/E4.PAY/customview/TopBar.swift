//
//  TopBar.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/11.
//

import UIKit


protocol SideMenu : AnyObject {
    func openSideMenu()
    func goBack()
    
}

@IBDesignable
class TopBar: UIView {

    weak var delegate: SideMenu!
    
    @IBOutlet weak var mainImage: UIImageView!
    
    @IBOutlet weak var menuBtn: UIButton!
    
    @IBOutlet weak var topBarNm: UILabel!
    @IBOutlet weak var backBtn: UIButton!
    
    var barCode : String = ""
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        xibSetup()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        xibSetup()
    }
    
    
    func xibSetup() {
        guard let view = loadViewFromNib(nib: "TopBar") else { return }
        view.frame = bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
    
    @IBAction func menuBtnClick(_ sender: Any) {
        
        delegate.openSideMenu()
        
    }
    
    @IBAction func goBackClick(_ sender: Any) {
        
        delegate.goBack()
        
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}




