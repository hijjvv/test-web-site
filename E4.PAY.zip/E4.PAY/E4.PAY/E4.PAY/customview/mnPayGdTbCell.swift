//
//  mnPayGdTbCell.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit

class mnPayGdTbCell: UITableViewCell {

    @IBOutlet weak var gdNm : UILabel?
    @IBOutlet weak var gdImg : UIImageView?
    @IBOutlet weak var gdAmt : UILabel?
    @IBOutlet weak var buyBtn : UIButton?
    var gdCtgr : String?
    
    var buttonHandler: (() -> Void)?
    
    
    
    @IBAction func buttonTapped(sender: UIButton) {
            buttonHandler?()
            
            // 여기서 원하는 이벤트 처리
        }

    
    
}
