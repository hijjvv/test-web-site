//
//  mnUseCtgrCellCollectionViewCell.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit

class mnUseCtgrCell: UICollectionViewCell {
    
    @IBOutlet weak var
titleLabel: UILabel!

      // 셀의 내용을 설정하는 메서드
      func configure(withTitle title: String) {
          titleLabel.text = title
      }
    
}
