//
//  mnUseListViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit
import Alamofire

class mnUseListViewCtr: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,SideMenu{
    func openSideMenu() {
      return
    }
    
    func goBack() {
        self.navigationController?.popViewController(animated: true)
    }
    

    
    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var yearTextField: UITextField!
    
    @IBOutlet weak var monthTextField: UITextField!
    
    private var yearPickerView: UIPickerView!
     private var monthPickerView: UIPickerView!

    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var mnUseTbList: UITableView!
    
    private var isDefaultSelect = true
    var initialSelectedItemIndex: Int = 0
    let sectionNm : [String] = ["전체","결제","충전","송금"]
    var selectNo : Int = 0
    var selectYear  = String (Calendar.current.component(.year, from: Date())) + "년"
    var selectMonth = "전체"
    
    var dataList : [MnUseDto] = []
    var dataList2 : [ResMnUseDto] = []
    var dataList3 : [ResMnUseDto] = []
    
    var filterList : [MnUseDto] = []
    
    let allDataList : [MnUseDto] = [MnUseDto.init(regDt: "24.01.02", gdNm: "스타벅스원두", payAmt: "3000", mnCd: "결제"),MnUseDto.init(regDt: "24.02.02", gdNm: "스타벅스원두", payAmt: "3000", mnCd: "결제"),MnUseDto.init(regDt: "24.03.02", gdNm: "머니충전", payAmt: "3000", mnCd: "충전")]

    
    let years = Array(2020...2030)
       let months = ["전체","1","2","3","4","5","6","7","8","9","10","11","12"]

       override func viewDidLoad() {
           super.viewDidLoad()

           // 년도를 표시할 TextField와 UIPickerView 설정
           
           yearPickerView = UIPickerView()
           yearPickerView.delegate = self
           yearPickerView.dataSource = self
           yearTextField.inputView = yearPickerView

           // 월을 표시할 TextField와 UIPickerView 설정
           monthPickerView = UIPickerView()
           monthPickerView.delegate = self
           monthPickerView.dataSource = self
           monthTextField.inputView = monthPickerView

           // 년도와 월을 초기값으로 설정 (예: 현재 날짜 기준)
           let currentDate = Date()
           let components = Calendar.current.dateComponents([.year, .month], from: currentDate)
           if let year = components.year, let month = components.month {
               yearTextField.text = "\(year)년"
               monthTextField.text = "전체"
           }

           collectionView.delegate = self
           collectionView.dataSource = self

               // 수평 스크롤을 위해 UICollectionViewFlowLayout 사용
               if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                   layout.scrollDirection = .horizontal
               }
           
           setting()
           
           let initialIndexPath = IndexPath(item: 0, section: 0)
                   
                   // collectionView의 선택된 셀의 배경색 변경 및 필요한 작업들을 수행합니다.
           collectionView(collectionView, didSelectItemAt: initialIndexPath)
           
           getMnUseApi()

       }
    

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sectionNm.count // 아이템 개수
       }

       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           

           
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mnUseCtgrCell", for: indexPath) as! mnUseCtgrCell

           cell.titleLabel.text = sectionNm[indexPath.item]
           
           cell.layer.cornerRadius = 25
           cell.layer.masksToBounds = true
           cell.layer.borderWidth = 0.8
           cell.layer.borderColor = UIColor.systemGray6.cgColor
           // 셀의 내용 설정
           
           if indexPath.item == 0 && isDefaultSelect == true {
               cell.isSelected = true
               collectionView.selectItem(at: indexPath, animated: false, scrollPosition: .init())
               cell.backgroundColor = UIColor(hex: 0x141726)
           }
           

           return cell
       }
     func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // 선택된 셀의 배경색 변경
        if let selectedCell = collectionView.cellForItem(at: indexPath) as? mnUseCtgrCell {
            selectedCell.backgroundColor = UIColor(hex: 0x141726)
        }
         
         self.selectNo = indexPath.item
         dataList3.removeAll()
         //dataFilter()
         //dataDateFilter()
         getMnUseApi()
         self.mnUseTbList.reloadData()
         
    }

     func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        // 선택이 해제된 셀의 배경색 원래대로 변경
        if let deselectedCell = collectionView.cellForItem(at: indexPath) as? mnUseCtgrCell {
            deselectedCell.backgroundColor = UIColor.clear // 또는 다른 기본 색상
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 60, height: 45)
        }
    
    

    func setting(){
        mnUseTbList.layer.cornerRadius = 8
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        /// 툴바 세팅
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let btnDone = UIBarButtonItem(title: "확인", style: .done, target: self, action: #selector(onPickDone))
        let space = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil)
        toolBar.setItems([btnDone], animated: true)
        toolBar.isUserInteractionEnabled = true
        
        /// 텍스트필드 입력 수단 연결
        self.yearTextField.inputAccessoryView = toolBar
        self.monthTextField.inputAccessoryView = toolBar
        
        
    }
    
    @objc func onPickDone() {
        /// 확인 눌렀을 때 액션 정의 -> 아래 코드에서는 라벨 텍스트 업데이트
        selectYear  = yearTextField.text!
        selectMonth =  monthTextField.text!
        yearTextField.resignFirstResponder() /// 피커뷰 내림
        monthTextField.resignFirstResponder() /// 피커뷰 내림
        dataList3.removeAll()
        //dataFilter()
        //dataDateFilter()
        getMnUseApi()
        mnUseTbList.reloadData()
     
    }
    
    func dataFilter(){
        filterList = allDataList
        
        if (sectionNm[self.selectNo] == "전체"){
            dataList = filterList
            return
        }
        
        
        for  i in 0..<filterList.count {
            var selectCtgr = sectionNm[self.selectNo]
            if (selectCtgr == filterList[i].mnCd) {
                self.dataList.append(filterList[i])
            }
           
        }
        
    }
    
    func dataDateFilter(){
        //filterList = allDataList
        filterList = dataList
        dataList.removeAll()

        var yearFilterList : [MnUseDto] = []
        var dateFilterList : [MnUseDto] = []
        var cvData = filterList
        var cvYear = selectYear
        var cvMonth = selectMonth
        cvYear.removeLast()
        cvMonth.removeLast()
        for  i in 0..<filterList.count {
            var components = cvData[i].regDt.components(separatedBy: ".")
            var useDate2 = components[0]
            if (selectMonth == "전체"){
                for  i in 0..<filterList.count {
                    if(String(cvYear).suffix(2) == useDate2){
                        dataList.append(filterList[i])
                    }
                }
                filterList = dataList
                return
            }else {
                
          
                var monthString = components[1]
                
                if(String(cvYear).suffix(2) == useDate2 &&
                   Int(cvMonth)  == Int(monthString)  )
                {
                    dataList.append(filterList[i])
                }
                
            }
            }

        filterList = dataList
        
        }
    
    
    
    func getMnUseApi( ){
            
        var mbrNo = UserDefaults.standard.string(forKey: "mbrNo")
        
        
        var formattedNumber = ""
            var monthWithoutSuffix = self.selectMonth.replacingOccurrences(of: "월", with: "")
            if self.selectMonth != "전체"{
                if monthWithoutSuffix.count == 1 {
                    formattedNumber = "0" + monthWithoutSuffix
                }
            } else {
                
            }
        
        var data = [String: Any]()
        

        var sectionCd = ""
        switch  self.selectNo {
        case 0 :
            sectionCd = ""
        case 1 :
            sectionCd = "10"
        case 2 :
            sectionCd = "90"
        case 3 :
            sectionCd = "50"
        default:
            sectionCd  = ""
        }
        
        
        data["trxClCd"]  = sectionCd
   
        var yearWithoutSuffix = self.selectYear.replacingOccurrences(of: "년", with: "")
        data["inqStaDt"] = yearWithoutSuffix + formattedNumber
        print(yearWithoutSuffix += formattedNumber)
        if let mbrNo = mbrNo {
            data["mbrNo"] = mbrNo
        }

        let apiUrl = "http://192.168.10.150:48080/money/trnList"

        let header: HTTPHeaders = [
                "Content-Type": "application/json;charset=UTF-8"
            ]
                
        NetworkManager.shared.request(url: apiUrl, method: .get, parameters: data , encoding: URLEncoding.queryString ,headers : header) { result in
                switch result {
                case .success(let value):
                    let data = value as? [String : Any]
                    let data2 = data?["rpsCd"]
                    if (data2 as? String  == "000"){
                        do {
                            //completion(true)
                            if let dataList2 = data?["monyTrxItm"]{
                                
                                let rdata = try JSONSerialization.data(withJSONObject: dataList2, options: .prettyPrinted)
                                let cfData = try JSONDecoder().decode([ResMnUseDto].self, from: rdata)
                                
                                self.dataList3 = cfData
                            }
                            
                            self.mnUseTbList.reloadData()
                            
                            print("Success:")
                        }catch{
                            print("Error: ")
                        }
                    }else {
                        print("Error: ")
                        return
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
            
        }
    

   }











extension mnUseListViewCtr: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == yearPickerView {
            return years.count
        } else if pickerView == monthPickerView {
            return months.count
        }
        return 0
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == yearPickerView {
            return "\(years[row])년"
        } else if pickerView == monthPickerView {
            if(months[row] == "전체"){
                return "\(months[row])"
            }
            return "\(months[row])월"
        }
        return nil
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == yearPickerView {
            yearTextField.text = "\(years[row])년"
        } else if pickerView == monthPickerView {
            if(months[row] == "전체"){
                monthTextField.text = "\(months[row])"
            }else{
                monthTextField.text = "\(months[row])월"
            }
        }
        pickerView.resignFirstResponder()
        
    }
    


    
}


extension mnUseListViewCtr : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        dataList3.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mnUseTbList.dequeueReusableCell(withIdentifier: "mnUseTbCell", for : indexPath)as!
        mnUseTbCell
        
        cell.regDt?.text = dataList3[indexPath.row].trxDt
        cell.gdNm?.text = dataList3[indexPath.row].prodNm
  
        if let cd = dataList3[indexPath.row].mchtNm {
                cell.mnCd?.text = "결제"
            } else {
                cell.mnCd?.text = "은행거래"
            }
        
        cell.payAmt?.text =  NumberUtil.shared.formatAmountWithoutDecimal(amount: dataList3[indexPath.row].trxAmt ?? 0)
        
        return cell
    }
    
    
}
