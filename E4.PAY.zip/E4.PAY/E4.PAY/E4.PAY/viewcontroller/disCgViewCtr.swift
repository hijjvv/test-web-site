//
//  disCgViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit
import Alamofire

class DisCgViewCtr: UIViewController, UIGestureRecognizerDelegate ,SecretKeyDelegate, SideMenu {
    func openSideMenu() {
       return
    }
    
    func goBack() {
        self.navigationController?.popViewController(animated: true)

    }
    
    func outputData(Str: String, inputIdx: Int) {
        if Str == "초기화"{
            inputAmt.removeAll()
            var cvInput = NumberUtil.shared.formatAmountWithoutDecimal(amount: Int(inputAmt) ?? 0)
            self.amountLb.text = cvInput + "원"
           return
        }
        if Str == "back"{
            inputAmt.removeLast()
            var cvInput = NumberUtil.shared.formatAmountWithoutDecimal(amount: Int(inputAmt) ?? 0)
            self.amountLb.text = cvInput + "원"
            return
        }
        inputAmt.append(Str)
        var cvInput = NumberUtil.shared.formatAmountWithoutDecimal(amount: Int(inputAmt)!)
        self.amountLb.text = cvInput + "원"
    }
    
    

    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var commentLb: UILabel!
    
    @IBOutlet weak var amountLb: UILabel!
    
    @IBOutlet weak var disChargeBtn: UIButton!
    
    @IBOutlet weak var actBox: UIView!
    
    var inputAmt : String = ""

    @IBOutlet weak var myBankNm: UILabel!
    @IBOutlet weak var myAccount: UILabel!
    
    var forCloseCustomView: UIView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topBar.menuBtn.isHidden = true
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped))
        tapGesture.delegate = self
        amountLb.addGestureRecognizer(tapGesture)
        amountLb.isUserInteractionEnabled = true
        topBar.delegate = self
        setUp()
        
        // Do any additional setup after loading the view.
    }
    
    
    func setUp(){
        
        
        
        amountLb.layer.cornerRadius = 20
        actBox.layer.cornerRadius = 8
        disChargeBtn.layer.cornerRadius = 8
        myBankNm.text = UserDefaults.standard.string(forKey: "instNm")
        myAccount.text = UserDefaults.standard.string(forKey: "acntNo")
        
        
        
    }
    
    
    @objc func labelTapped() {
        
//        guard let keypadCtr = Bundle.main.loadNibNamed("Keypad", owner: nil, options: nil)?.first as? KeypadView else {
//                   return
//               }
        
        let keypadCtr = KeypadView()
        keypadCtr.tag = 4
        keypadCtr.frame = CGRect(x: 0, y: view.bounds.height - 325, width: view.bounds.width, height: 325)

        keypadCtr.delegate = self
        view.addSubview(keypadCtr)
        
        let tapOutsideGesture = UITapGestureRecognizer(target: self, action: #selector(outsideTapped))
        view.addGestureRecognizer(tapOutsideGesture)


        
        // 저장해둡니다.
        forCloseCustomView = keypadCtr
        
    }
    
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
           return true
       }
    
    
    @objc func outsideTapped(_ sender: UITapGestureRecognizer) {
          let location = sender.location(in: view)

          // customView 외부를 탭하면 띄운 화면을 닫습니다.
          if let customView = forCloseCustomView, !customView.frame.contains(location) {
              customView.removeFromSuperview()
              view.gestureRecognizers?.removeAll()
          }
      }
    

    @IBAction func disChargeClick(_ sender: Any) {
        
        if ( Int(inputAmt) ?? 0 < 10000 ){
            self.commentLb.text = "최소 환불금액은 10,000원 입니다"
            return
        }
        
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "DisCgCpViewCtr") as? DisCgCpViewCtr else {return}
        
        disChargeApi(){ result in
            
            if result == true {
                pushVC.bankNmVal = self.myBankNm.text
                pushVC.acntNoVal = self.myAccount.text
                self.navigationController?.pushViewController(pushVC, animated: true)
            } else {
                return
            }
            
        }
        
        
    }
    
    
    func disChargeApi(completion: @escaping (_ isCheck : Bool) -> Void ) {
        
        let apiUrl = "http://192.168.10.150:48080/money/withdraw"
        let mbrNo  = UserDefaults.standard.string(forKey: "mbrNo")
        var param = ["mbrNo" : Int(mbrNo!), "wdMony"  : Int(self.inputAmt)] as? [String : Any]
        let header: HTTPHeaders = [
                "Content-Type": "application/json;charset=UTF-8"
            ]
        
        NetworkManager.shared.request(url: apiUrl, method: .get,parameters: param , encoding: URLEncoding.default,headers: header) { result in
            switch result {
            case .success(let value):
                let data = value as? [String : Any]
                let data2 = data?["rpsCatgCd"]
                if (data2 as? String == "정상"){
                    completion(true)
                }else {
                    completion(false)
                }
          
             
            case .failure(let error):
                print("Error: \(error)")
            }
        }
        
    }
    
    
    
    
}
