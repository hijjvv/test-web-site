//
//  SearchPostViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/16.
//

import UIKit

class SearchPostViewCtr: UIViewController, UIGestureRecognizerDelegate, SideMenu {
    func openSideMenu() {
        return
    }
    
    func goBack() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    
    @IBOutlet weak var searchBtn: UIButton!
    
    @IBOutlet weak var postInput: UITextField!
    
    @IBOutlet weak var postInput2: UITextField!
    
    @IBOutlet weak var nextBtn: UIButton!
    
    
    @IBOutlet weak var topBar: TopBar!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        topBar.delegate = self

        // Do any additional setup after loading the view.
        let tapOutsideGesture = UITapGestureRecognizer(target: self, action: #selector(outsideTapped))
        view.addGestureRecognizer(tapOutsideGesture)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(searchPost))
        tapGesture.delegate = self
        postInput.addGestureRecognizer(tapGesture)
        topBar.menuBtn.isHidden = true
        postInput.addLeftPadding()
        postInput2.addLeftPadding()
        postInput.layer.cornerRadius = 8
        postInput2.layer.cornerRadius = 8
        nextBtn.layer.cornerRadius = 8
    }
    

    @IBAction func searchPost(_ sender: Any) {
        
        let prsntVC = KakaoZipCodeVC()
        
        present(prsntVC, animated: true)
    }
    
    @objc func outsideTapped(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: view)
        
        view.endEditing(true)

    }
    
    @IBAction func goNext(_ sender: Any) {
        
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "RegiNumViewCtr") as? RegiNumViewCtr else {return}
        self.navigationController?.pushViewController(pushVC, animated: true)
        
        
    }
    
    
    
    
}
