//
//  AgreePage.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/08.
//

import UIKit

extension UIColor {
    convenience init(hex: Int, alpha: CGFloat = 1.0) {
        self.init(
            red: CGFloat((hex & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((hex & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(hex & 0x0000FF) / 255.0,
            alpha: alpha
        )
    }
}



class AgreePageCtr: UIViewController {
    
    
    
    
    
    
    @IBOutlet weak var allBtn: UIButton!
    
    @IBOutlet weak var checkBtn1: UIButton!
    
    @IBOutlet weak var checkBtn2: UIButton!
    
    @IBOutlet weak var checkBtn3: UIButton!
    
    @IBOutlet weak var checkBtn4: UIButton!
    
    
    @IBOutlet weak var nextBtn: UIButton!
    
    var toggle1 : Bool = false
    
    var toggleList : [Bool] = [false,false,false,false]
    
    var btnList : [UIButton] = []
    
    
    override func viewDidLoad() {
        
        nextBtn.isEnabled = false
        
        btnList.append(checkBtn1)
        btnList.append(checkBtn2)
        btnList.append(checkBtn3)
        btnList.append(checkBtn4)
        
        super.viewDidLoad()

        }
    

    @IBAction func allAgreeEv(_ sender: Any) {
        setToggle()
        if (toggle1 == true) {
            nextBtn.backgroundColor  = UIColor(hex: 0xFF725E)
            nextBtn.isEnabled = true
        }else{
            nextBtn.backgroundColor  = UIColor(hex: 0xAAAAAA)
            nextBtn.isEnabled = false
        }
    }
    
    @IBAction func AgreeEv(_ sender: UIButton) {

        setToggleList(tag: sender.tag)
        if (toggle1 == true) {
            nextBtn.backgroundColor  = UIColor(hex: 0xFF725E)
            nextBtn.isEnabled = true
        }else {
            nextBtn.backgroundColor  = UIColor(hex: 0xAAAAAA)
            nextBtn.isEnabled = false
        }
        
        
    }
    
    func setToggle() {
        toggle1.toggle()

        for i in 0..<toggleList.count{
            toggleList[i] = toggle1
       
        if toggle1 == true {
            btnList[i].setImage(UIImage(named: "checkTrue"), for: .normal  )
            allBtn.setImage(UIImage(named: "checkTrue"), for: .normal  )
        } else {
            btnList[i].setImage(UIImage(named: "noneCheck"), for: .normal  )
            allBtn.setImage(UIImage(named: "noneCheck"), for: .normal  )
            
        }
        }
        
        
        
        }
    
    func setToggleList(tag : Int) {
        
        toggleList[tag].toggle()
        toggleList[tag]
        if toggleList[tag] == true {
            btnList[tag].setImage(UIImage(named: "checkTrue"), for: .normal  )
            
            if(toggleList[0]&&toggleList[1]&&toggleList[2]&&toggleList[3]){
                toggle1 = true
                allBtn.setImage(UIImage(named: "checkTrue"), for: .normal  )
                
                
            }
            
        } else {
            btnList[tag].setImage(UIImage(named: "noneCheck"), for: .normal  )
            toggle1 = false
            allBtn.setImage(UIImage(named: "noneCheck"), for: .normal  )
            
        }
        
        
        
        }
    
    @IBAction func nextBtnClick(_ sender: Any) {
        
        func dismissPreviousViewControllers() {
//             self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
//             self.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
//             self.presentingViewController?.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
//             self.presentingViewController?.presentingViewController?.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
         }
        
    }
    
}



