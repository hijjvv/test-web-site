//
//  CardSecretViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/16.
//

//
//  SecretKeyView.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/09.
//

import UIKit


class CardSecertViewCtr :  UIViewController , SecretKeyDelegate, SideMenu, CmPopUpProtocol {
    func clickYes() {
        return
    }
    
    func clickNo() {
   
    }
    
    func clickOk() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    func openSideMenu() {
        return
    }
    
    func goBack() {
        if (self.navigationController != nil){
            self.navigationController?.popViewController(animated: true)
        }else{
            self.dismiss(animated: true)
        }
    }
    
    
    @IBOutlet weak var inputField: CardSecret!

    @IBOutlet weak var secretKey: KeypadView!
    
    
    @IBOutlet weak var topBar: TopBar!
    
    
    var logicCode = ""
    
    var secretKeyVal : String = ""
    
    func outputData(Str: String , inputIdx : Int) {
        
        if (Str == "back"){
        inputField.labelList[inputIdx].backgroundColor = UIColor(hex: 0xD1D1D6)
            secretKeyVal.removeLast()
            return
        }
        
        if (Str == "초기화"){
            for i in 0..<inputField.labelList.count {
                inputField.labelList[i].backgroundColor = UIColor(hex: 0xD1D1D6)
            }

            secretKeyVal.removeAll()
            return
        }
        
    
        inputField.labelList[inputIdx].backgroundColor = UIColor(hex: 0x000000)
        secretKeyVal += Str
        
        if (secretKeyVal.count == 4){
            sucRegCard()
        }
        

        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        secretKey.delegate = self
        topBar.delegate = self
        topBar.menuBtn.isHidden = true

        
        }
    
    


    
    func sucRegCard(){
        let cmPopUp = CmPopUp()
        
        cmPopUp.delegate = self
        cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        cmPopUp.layer.cornerRadius = 10
        cmPopUp.layer.masksToBounds = true
        cmPopUp.popUpNm.text = "카드 사용등록이 완료되었습니다."
        cmPopUp.popUpCont.text = "E4.PAY카드결제로 다양한 혜택을 누려보세요."
        cmPopUp.yesBtn.isHidden = true
        cmPopUp.noBtn.isHidden = true
        cmPopUp.center = view.center
        
        //
        let topBorder = CALayer()
        topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.okBtn.frame.size.width, height: 0.5)
        topBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.okBtn.layer.addSublayer(topBorder)
        
        
        let darkBackgroundView = UIView(frame: view.bounds)
        darkBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        darkBackgroundView.alpha = 0
        view.addSubview(darkBackgroundView)
        

        
        
        
        // 팝업을 띄우기 위한 애니메이션
        cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        cmPopUp.alpha = 0
        view.addSubview(cmPopUp)
        
        UIView.animate(withDuration: 0.3) {
            darkBackgroundView.alpha = 1
            cmPopUp.alpha = 1
            cmPopUp.transform = CGAffineTransform.identity
            
        }
    }
    

    
    
}

