//
//  IdentiView.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/11.
//

//  내 UUID = C0CECEE2-582A-461C-8CF0-A56EEB54CABC

import Foundation
import UIKit
import Alamofire

extension UITextField {
  func addLeftPadding() {
    let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.frame.height))
    self.leftView = paddingView
    self.leftViewMode = ViewMode.always
  }
}


extension UIViewController  {
    func addDoneButtonToKeyboard(textField: UITextField) {
        let keyboardToolbar = UIToolbar()
        keyboardToolbar.sizeToFit()

        let flexBarButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let doneBarButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneButtonTapped))

        keyboardToolbar.items = [flexBarButton, doneBarButton]

        textField.inputAccessoryView = keyboardToolbar

    }

    @objc func doneButtonTapped() {
        view.endEditing(true)
    }
}




class IdentiView: UIViewController,UITextFieldDelegate, CmPopUpProtocol {
    func clickYes() {
       
    }
    
    func clickNo() {
        return
    }
    
    func clickOk() {
        if(popUpLogicCd == "1"){
            self.cmPopUp.commonHidePopUp(vc: self, cmPopUp: self.cmPopUp)
   
        }
        else if(popUpLogicCd == "2"){
            guard let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecertKeyView") as? SecertKeyView else {return}

            pushVC.modalPresentationStyle = .fullScreen
            pushVC.logicCode = "3"
            self.present(pushVC, animated: true)
            self.cmPopUp.commonHidePopUp(vc: self, cmPopUp: self.cmPopUp)
            self.cmPopUp.transform = CGAffineTransform.identity
        }
        else if(popUpLogicCd == "3"){
            guard let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AccountConView") as? AccountConView else {return}

            pushVC.modalPresentationStyle = .fullScreen
            self.present(pushVC, animated: true)
            self.cmPopUp.commonHidePopUp(vc: self, cmPopUp: self.cmPopUp)
            self.cmPopUp.transform = CGAffineTransform.identity
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }
    
    @IBOutlet weak var inputNm: UITextField!
    @IBOutlet weak var inputPnb: UITextField!
    @IBOutlet weak var inputIdCd: UITextField!
    @IBOutlet weak var sendCdBtn: UIButton!
    @IBOutlet weak var cdCkBtn: UIButton!
    @IBOutlet weak var idtfBtn: UIButton!
    @IBOutlet weak var nextBtn: UIButton!
    @IBOutlet weak var commentLb: UILabel!
    
    let cmPopUp = CmPopUp()
    var popUpLogicCd = ""
    
    var svcReqUnqNo = ""
    var isCheck = false
    
    let apiKey    = "NCS11UB0B7W57MQU"
    let secretKey = "JM7DTOXCVDOB7GFUH4GUZGVKTOUP13BW"
    
    func setUp() {
        cmPopUp.delegate = self
        inputNm.delegate = self
        inputPnb.delegate = self
        inputIdCd.delegate = self
        addDoneButtonToKeyboard(textField : inputNm)
        addDoneButtonToKeyboard(textField : inputPnb)
        addDoneButtonToKeyboard(textField : inputIdCd)
        inputNm.layer.cornerRadius = 8
        inputPnb.layer.cornerRadius = 8
        inputIdCd.layer.cornerRadius = 8
        sendCdBtn.layer.cornerRadius = 8
        cdCkBtn.layer.cornerRadius = 8
        idtfBtn.layer.cornerRadius = 8
        nextBtn.layer.cornerRadius = 8
        inputNm.addLeftPadding()
        inputPnb.addLeftPadding()
        inputIdCd.addLeftPadding()
        
        sendCdBtn.addTarget(self, action: #selector(sendIdtfCd), for: .touchUpInside)
        idtfBtn.addTarget(self, action: #selector(getIdtfPhone), for: .touchUpInside)
        
    }
    
    //빈화면 터치시 키보드 내리기
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
         self.view.endEditing(true)
        return
   }
    
    // return 버튼 클릭시 키보드 내리기
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    @IBAction func goLogin(_ sender: Any) {
        
        guard let pushVC = self.storyboard?.instantiateViewController(withIdentifier: "SecertKeyView") as? SecertKeyView else {return}
    
        pushVC.logicCode = "3"
        
        pushVC.modalPresentationStyle = .fullScreen
        self.present(pushVC, animated: true, completion: nil)
        
    }
    
    @objc func sendIdtfCd(){
        let url = "http://192.168.10.150:48080/member/getcool-sms"
        
        var uuid = UIDevice.current.identifierForVendor!.uuidString
        uuid.removeLast()
        uuid += "E"
        print ("uuid : ", uuid)
        var param = ["mbrNm" : inputNm.text,  "apiKey":apiKey,"secretKey":secretKey,"uuid":uuid,"hpNo":self.inputPnb.text] as [String : Any]
        
        AF.request(url,
                   method : .get,
                   parameters : param,
                   encoding : URLEncoding.default
        )
        .validate(statusCode: 0..<399)
        .responseJSON   {
            response in
            switch response.result {
                
            case .success(let value ):
                

                
                let data = value as? [String : Any]
                if (data?["rpsCd"] as? String == "000") {
                    print("POST 성공" , data?["rpsCd"])
                    do {
                        self.svcReqUnqNo = data?["svcReqUnqNo"] as! String
                    } catch {
                        print("error")
                    }
                } else {
                    print("error : ")
                }
                
                // print("token받기" , userInfo)
            case .failure(let error):
                print("error : \(error.errorDescription!)")
                print("error :", error)
            }
        }
        
        
    }
    
    
    
    @objc func getIdtfPhone(){
        let url = "http://192.168.10.150:48080/member/checkcool-sms"
        
        var uuid = UIDevice.current.identifierForVendor!.uuidString
        uuid.removeLast()
        uuid += "E"
        var param = ["svcReqUnqNo":self.svcReqUnqNo,"authNo" : inputIdCd ] as [String : Any]
        
        AF.request(url,
                   method : .get,
                   parameters : param,
                   encoding : URLEncoding.default
        )
        .validate(statusCode: 0..<400)
        .responseJSON   {
            response in
            switch response.result {
                
            case .success(let value ):
                
                let data = value as? [String : Any]
                if (data?["rpsCd"] as? String == "000") {
                    print("POST 성공" , data?["rpsCd"])
                    
                    if(data?["authRsltCd"] as? String == "00"){
                        self.isCheck = true
                        self.commentLb.text = "핸드폰 인증이 완료되었습니다."
                    } else {
                        self.commentLb.text = "인증실패, 인증번호를 확인해주세요"
                    }
                    do {
                  
                    } catch {
                        print("error")
                    }
                } else {
                    print("error : ")
                }
                
                // print("token받기" , userInfo)
            case .failure(let error):
                print("error : \(error.errorDescription!)")
                print("error :", error)
            }
        }
        
        
    }
    
    
    @IBAction func goSignUp(_ sender: Any) {
        var uuid = UIDevice.current.identifierForVendor!.uuidString
        uuid.removeLast()
        uuid += "E"
        var usrInfo = MbrInfo()
        usrInfo.mbrNm = inputNm.text
        usrInfo.hpNo  = inputPnb.text
        usrInfo.uuid  = uuid
        
        if (!checkInput1(str: inputNm.text ?? "" )) {
            popUpLogicCd = "1"
            cmPopUp.commonPopUp(vc: self, cmPopUp: self.cmPopUp, head: "본인인증", content: "올바른 이름을 입력하세요", logicCd: "1")
            return
        }
        
        if (!checkInput2(str: inputPnb.text ?? "" )) {
            popUpLogicCd = "1"
            cmPopUp.commonPopUp(vc: self, cmPopUp: self.cmPopUp, head: "본인인증", content: "휴대폰번호를 입력하세요 \n ( - 없이 입력)", logicCd: "1")
            return
        }
        
        do{
        let encoder = JSONEncoder()
        let data = try encoder.encode(usrInfo)
        
            UserDefaults.standard.set(data , forKey: "usrInfo")
        } catch {
                 print("Error decoding struct: \(error)")
            
        }
        checkUuid(){ [self] result in
            
            if result == true {
                popUpLogicCd = "2"
                self.cmPopUp.commonPopUp(vc: self, cmPopUp: self.cmPopUp, head: "회원인증", content: "기가입 회원입니다 로그인 페이지로 이동합니다", logicCd: "1")
            }else if result == false  {
                popUpLogicCd = "3"
                self.cmPopUp.commonPopUp(vc: self, cmPopUp: self.cmPopUp, head: "회원인증", content: "회원정보가 없습니다 회원가입페이지로 이동합니다", logicCd: "1")
            }
            
        }
        
  
        }
    
    
    
    func checkUuid( completion: @escaping (_ isCheck : Bool) -> Void ){
            
        var uuid = UIDevice.current.identifierForVendor!.uuidString
        uuid.removeLast()
        uuid += "E"
        var data = ["uuid" : uuid]
        
            let apiUrl = "http://192.168.10.150:48080/member/checkuuid"

            let header: HTTPHeaders = [
                    "Content-Type": "application/json;charset=UTF-8"
                ]
                
                NetworkManager.shared.request(url: apiUrl, method: .get, parameters: data , encoding: URLEncoding.default ,headers : header) { result in
                switch result {
                case .success(let value):
                    let data = value as? [String : Any]
                    let data2 = data?["exsist"]
                    if (data2 as! Bool == true){
                        do {
                            var mbrNo = data?["mbrNo"] as? String
                            UserDefaults.standard.set(mbrNo, forKey: "mbrNo")
                            completion(true)
                            print("Success:")
                        }catch{
                            print("Error: ")
                        }
                    }else {
                        completion(false)
                        print("Error: ")
                        return
                    }
                case .failure(let error):
                    completion(false)
                    print("Error: \(error)")
                }
            }
            
        }
    
    
}



func checkInput1(str : String) -> Bool {
    let koreanNameRegex = "^[가-힣]{2,5}$"
    let namePredicate = NSPredicate(format: "SELF MATCHES %@", koreanNameRegex)
    return namePredicate.evaluate(with: str)
}

func checkInput2(str : String) -> Bool {
    let phoneNumber = "^[0-9]{5,18}$"
    let phoneNumberPredicate = NSPredicate(format: "SELF MATCHES %@", phoneNumber)
    return phoneNumberPredicate.evaluate(with: str)
}
