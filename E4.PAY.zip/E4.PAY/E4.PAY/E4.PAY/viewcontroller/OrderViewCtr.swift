//
//  orderViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit
import Alamofire

class OrderViewCtr: UIViewController, SideMenu, CmPopUpProtocol {
    func clickYes() {
        
        if(self.payLogicCd == "1"){
            chargeBuyApi()
        }else {
            goChargeAndBuy()
        }
    }
    
    func clickNo() {
        hidePopup()
    }
    
    func clickOk() {
    self.navigationController?.popViewController(animated: true)

    }
    
    func openSideMenu() {
       return
    }
    
    func goBack() {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    
    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var gdImg: UIImageView!
    
    @IBOutlet weak var gdNm: UILabel!
    
    @IBOutlet weak var merchantNm: UILabel!
    @IBOutlet weak var gdAmt: UILabel!
    
    var data = GdDto(gdNm: "", gdImg: UIImage(), gdAmt: "", gdCtgr: "" )
    var usePossMony = UserDefaults.standard.integer(forKey: "usePossMony")
    var payLogicCd = ""
    
    
    let cmPopUp = CmPopUp()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        
        gdImg.image = data.gdImg
        gdNm.text = data.gdNm
        gdAmt.text = data.gdAmt
        merchantNm.text = data.gdCtgr
        cmPopUp.delegate = self
        cmPopUp.okBtn.isHidden = true
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func funcBuy(_ sender: Any) {
        
        cpAndGoPopUp()
        
    }
    
    func cpAndGoPopUp(){
        
        var gdAmtInt = 0
        if let data1 = self.gdAmt.text?.replacingOccurrences(of: ",", with: ""),
           let identifier1 = Int(data1) {
            gdAmtInt = identifier1
        }

        cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        cmPopUp.layer.cornerRadius = 10
        cmPopUp.layer.masksToBounds = true
        cmPopUp.popUpNm.text = "결제를 진행해주세요."
        cmPopUp.popUpCont.text = "상품을 구매하시겠습니까?."
        
        if(usePossMony <  gdAmtInt ){
//            cmPopUp.popUpNm.text = "충전 후 결제"
//            cmPopUp.popUpCont.text = "머니 잔액이 부족합니다 충전 후\n결제를 진행 하시겠습니까?"
        cmPopUp.yesBtn.isHidden = true
        cmPopUp.noBtn.isHidden  = true
        cmPopUp.okBtn.isHidden = false
        cmPopUp.popUpNm.text = "잔액 부족"
        cmPopUp.popUpCont.text = "머니 잔액이 부족합니다 충전 후\n결제를 진행 해주세요"
            self.payLogicCd = "1"
        }
   
        cmPopUp.center = view.center
        
        //
        let topBorder = CALayer()
        topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.yesBtn.frame.size.width, height: 0.5)
        topBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.noBtn.layer.addSublayer(topBorder)
        
        let topBorder2 = CALayer()
        topBorder2.frame = CGRect(x: 0, y: 0, width: cmPopUp.yesBtn.frame.size.width, height: 0.5)
        topBorder2.backgroundColor = UIColor.gray.cgColor
        cmPopUp.yesBtn.layer.addSublayer(topBorder2)
        
        let topBorder3 = CALayer()
        topBorder3.frame = CGRect(x: 0, y: 0, width: cmPopUp.okBtn.frame.size.width, height: 0.5)
        topBorder3.backgroundColor = UIColor.gray.cgColor
        cmPopUp.okBtn.layer.addSublayer(topBorder3)

    
        
        let rightBorder = CALayer()
        rightBorder.frame = CGRect(x: cmPopUp.noBtn.bounds.width - 0.5, y: 0, width: 0.5, height: cmPopUp.yesBtn.bounds.height )
        rightBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.noBtn.layer.addSublayer(rightBorder)
        
        let darkBackgroundView = UIView(frame: view.bounds)
        darkBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        darkBackgroundView.alpha = 0
        darkBackgroundView.tag = 123
        view.addSubview(darkBackgroundView)
        

        
        
        
        // 팝업을 띄우기 위한 애니메이션
        
        cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        cmPopUp.alpha = 0
        view.addSubview(cmPopUp)
        
        UIView.animate(withDuration: 0.3) {
            darkBackgroundView.alpha = 1
            self.cmPopUp.alpha = 1
            self.cmPopUp.transform = CGAffineTransform.identity
            
        }
    }
    
    
    @objc func hidePopup() {
           // 팝업이 사라질 때 배경 어둡게 처리 해제
           if let darkBackgroundView = view.viewWithTag(123){
               UIView.animate(withDuration: 0.3, animations: {
                   darkBackgroundView.alpha = 0
               }) { (finished) in
                   if finished {
                       darkBackgroundView.removeFromSuperview()
                      
                   }
               }
           }

           // 팝업을 사라지게 하는 애니메이션
           UIView.animate(withDuration: 0.3, animations: {
               self.cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
               self.cmPopUp.alpha = 0
           }) { (finished) in
               if finished {
                   self.cmPopUp.removeFromSuperview()
                   self.cmPopUp.transform = CGAffineTransform.identity
               }
           }
       }
    
    func goChargeAndBuy() {
        
        buyApi(){ result in
         
            if( result == true){
                let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "ScBuyViewCtr") as? ScBuyViewCtr
                pushVC?.data.gdNm = self.gdNm?.text!
                pushVC?.data.gdImg = self.gdImg?.image!
                pushVC?.data.gdAmt = self.gdAmt?.text!
               self.navigationController?.pushViewController(pushVC!, animated: true)
            } else if (result == false) {
                
                let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "FaBuyViewCtr") as? FaBuyViewCtr
                pushVC?.data.gdNm = self.gdNm?.text!
                pushVC?.data.gdImg = self.gdImg?.image!
                pushVC?.data.gdAmt = self.gdAmt?.text!
               self.navigationController?.pushViewController(pushVC!, animated: true)
                
            }
            
        }
        

        
    }
    
    func chargeBuyApi(){
        
    }
    
    
    func buyApi( completion: @escaping (_ isCheck : Bool) -> Void ){
            
        var mbrNo = UserDefaults.standard.string(forKey: "mbrNo")

        
        var data = [String: Any]()
        data["trxClCd"] = "10"
        data["prodQty"] = 1
        data["prodNm"]  = self.gdNm.text

        if let mbrNo = mbrNo {
            data["mbrNo"] = mbrNo
        }
        if let trxAmtText = self.gdAmt.text?.replacingOccurrences(of: ",", with: ""), let trxAmt = Int(trxAmtText) {
            data["trxAmt"] = trxAmt
        }

        if let mchtNm = self.merchantNm.text {
            data["mchtNm"] = mchtNm
        }

        if let prodAmtText = self.gdAmt.text?.replacingOccurrences(of: ",", with: ""),let prodAmt = Int(prodAmtText) {
            data["prodAmt"] = prodAmt
        }
        
            let apiUrl = "http://192.168.10.150:48080/money/payAndCancel"

            let header: HTTPHeaders = [
                    "Content-Type": "application/json;charset=UTF-8"
                ]
                
        NetworkManager.shared.request(url: apiUrl, method: .post, parameters: data , encoding: URLEncoding.queryString ,headers : header) { result in
                switch result {
                case .success(let value):
                    let data = value as? [String : Any]
                    let data2 = data?["rpsCd"]
                    if (data2 as? String  == "000"){
                        do {
                            completion(true)
                            print("Success:")
                        }catch{
                            print("Error: ")
                        }
                    }else {
                        print("Error: ")
                        return
                    }
                case .failure(let error):
                    completion(false)
                    print("Error: \(error)")
                }
            }
            
        }
    
    

}

