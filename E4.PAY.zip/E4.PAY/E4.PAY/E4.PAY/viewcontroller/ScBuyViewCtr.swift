//
//  orderViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit

class ScBuyViewCtr: UIViewController, SideMenu {
    func openSideMenu() {
       return
    }
    
    func goBack() {
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    
    
    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var gdImg: UIImageView!
    
    @IBOutlet weak var gdNm: UILabel!
    
    @IBOutlet weak var gdAmt: UILabel!
    
    @IBOutlet weak var gdAmt2: UILabel!
    
    
    var data = GdDto(gdNm: "", gdImg: UIImage(), gdAmt: "", gdCtgr: "")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        
        gdImg.image = data.gdImg
        gdNm.text = data.gdNm
        gdAmt.text = data.gdAmt
        gdAmt2.text = data.gdAmt
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goHome(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    
}


class FaBuyViewCtr: UIViewController, SideMenu {
    func openSideMenu() {
       return
    }
    
    func goBack() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    @IBOutlet weak var commentLb: UILabel!
    
    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var gdImg: UIImageView!
    
    @IBOutlet weak var gdNm: UILabel!
    
    @IBOutlet weak var gdAmt: UILabel!
    
    var data = GdDto(gdNm: "", gdImg: UIImage(), gdAmt: "", gdCtgr: "")
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        
        gdImg.image = data.gdImg
        gdNm.text = data.gdNm
        gdAmt.text = data.gdAmt
        

        // Do any additional setup after loading the view.
    }
    

    @IBAction func goHome(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    
}
