//
//  SecretKeyView.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/09.
//

import UIKit
import Alamofire


class SecertKeyView :  UIViewController , SecretKeyDelegate, SideMenu, CmPopUpProtocol, UIGestureRecognizerDelegate {
    func clickYes() {
        cmPopUp.commonPopUp(vc: self, cmPopUp: self.cmPopUp, head: "머니 비밀번호 변경완료", content: "입력하신 비밀번호로 머니 비밀번호를 변경완료했습니다", logicCd: "1")
    }
    
    func clickNo() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    func clickOk() {
        if (self.navigationController != nil){
            self.navigationController?.popToRootViewController(animated: true)
        }else{
            self.dismiss(animated: true)
        }
    }
    
    func openSideMenu() {
        return
    }
    
    func goBack() {
        if (self.navigationController != nil){
            self.navigationController?.popViewController(animated: true)
        }else{
            self.dismiss(animated: true)
        }
    }
    
    
    @IBOutlet weak var inputField: SecretInput!

    @IBOutlet weak var secretKey: KeypadView!
    
    
    @IBOutlet weak var commentLb: UILabel!
    
    
    @IBOutlet weak var resetSecretLb: UILabel!
    
    @IBOutlet weak var topBar: TopBar!
    
    
    
    var logicCode = ""
    
    var secretKeyVal : String = ""
    var ckSecretKeyVal : String = ""
    var cmPopUp = CmPopUp()
  
    
    
    func outputData(Str: String , inputIdx : Int) {
        
        if (Str == "back"){
        inputField.labelList[inputIdx].backgroundColor = UIColor(hex: 0xD1D1D6)
            secretKeyVal.removeLast()
            return
        }
        
        if (Str == "초기화"){
            for i in 0..<inputField.labelList.count {
                inputField.labelList[i].backgroundColor = UIColor(hex: 0xD1D1D6)
            }

            secretKeyVal.removeAll()
            return
        }
        
    
        inputField.labelList[inputIdx].backgroundColor = UIColor(hex: 0x000000)
        secretKeyVal += Str
        
        if (secretKeyVal.count == 6 && logicCode == "1"){
            goSecret()
        }
        
        if (secretKeyVal.count == 6 && logicCode == "2"){
            
            if(secretKeyVal == ckSecretKeyVal){
                
                goSignUpFn()
            }else {
                commentLb.text = "비밀번호를 확인해 주세요"
            }

        }
        
        if (secretKeyVal.count == 6 && logicCode == "3"){
            
            loginApi(){ [self] result in
                if result == true{
                    loginSuccess()

                }else{
                    cmPopUp.commonPopUp(vc: self, cmPopUp: cmPopUp, head: "로그인", content: "비밀번호가 틀립니다!", logicCd: "1")
                }
                
            }
            
            
         
        }
        
        if (secretKeyVal.count == 6 && logicCode == "4"){
            goSecret()
        }
        
        if (secretKeyVal.count == 6 && logicCode == "5"){
            cmPopUp.commonPopUp(vc: self, cmPopUp: self.cmPopUp, head: "머니 비밀번호 변경", content: "입력하신 비밀번호로 머니 비밀번호를 변경합니다", logicCd: "2")
            //cpAndGoPopUp()
        }
        
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        outputData(Str: "초기화",inputIdx: 6)
        secretKey.idx = 0
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        secretKey.delegate = self
        topBar.delegate = self
        topBar.menuBtn.isHidden = true


        cmPopUp.delegate = self
        setUp()
        
        }
    func setUp() {
        if(logicCode == "2" || logicCode == "5" ){
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(reSetSecret))
            tapGesture.delegate = self
            resetSecretLb.addGestureRecognizer(tapGesture)
        }
        }
    @objc func reSetSecret(){
        
        if (self.navigationController != nil){
            self.navigationController?.popViewController(animated: true)
        }else{
            self.dismiss(animated: true)
        }
        
    }
    
    
    func goSecret(){
        
        guard let pushVC = self.storyboard?.instantiateViewController(withIdentifier: "SecretCheckView") as? SecertKeyView else {return}
    
        if(logicCode == "1"){
            pushVC.ckSecretKeyVal = self.secretKeyVal
            pushVC.logicCode = "2"
            pushVC.modalPresentationStyle = .fullScreen
            self.present(pushVC, animated: true)
        } else if (logicCode == "4"){
            pushVC.logicCode = "5"
            self.navigationController?.pushViewController(pushVC, animated: true)
        }
        
    }
    
    
    func goSignUpFn(){
        
        
        let data = UserDefaults.standard.data(forKey: "usrInfo")!
    
        signUpApi(){
            
            guard let pushVC = self.storyboard?.instantiateViewController(withIdentifier: "SignUpFn") as? SignUpFnView else {return}
            
            do{
                let rData = try JSONDecoder().decode(MbrInfo.self, from: data)
                pushVC.signUpData = rData
                
            } catch{
                
            }
            
            pushVC.modalPresentationStyle = .fullScreen
            self.present(pushVC, animated: true)
            
        }

        
   
        

        
        
    }
    
    
    func loginSuccess(){
        
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "PayMainPageView") as? UINavigationController else {return}
        
//
//        pushVC.modalPresentationStyle = .fullScreen
//        self.present(pushVC, animated: true, completion: nil)
//

        guard let pvc = self.presentingViewController else { return }
            self.dismiss(animated: true) {
                // 새로운 UINavigationController으로 이동
                //let secondNavigationController = UINavigationController(rootViewController: pushVC)
                
                // present 메서드를 사용하여 새로운 UINavigationController을 띄우기
                pushVC.modalPresentationStyle = .fullScreen
                pvc.present(pushVC, animated: true, completion: nil)
            }
        
        
//        if let navigationController = self.navigationController {
//            navigationController.setViewControllers([pushVC], animated: true)
//        }
        
        
        
    }
    
    
    func signUpApi( completion: @escaping () -> Void ){
        
        let data = UserDefaults.standard.data(forKey: "usrInfo")
        do {
            var jsonObject = try JSONSerialization.jsonObject(with: data!, options: []) as? [String: String]
            jsonObject?["monySertNo"] = self.secretKeyVal
            
            
        
        let apiUrl = "http://192.168.10.150:48080/member/register"

        let header: HTTPHeaders = [
                "Content-Type": "application/json;charset=UTF-8"
            ]
            
            NetworkManager.shared.request(url: apiUrl, method: .post, parameters: jsonObject , headers : header) { result in
            switch result {
            case .success(let value):
                let data = value as? [String : Any]
                let data2 = data?["rpsCd"]
                if (data2 as? String == "000"){
                    do {
                        let mbrNo : String = data?["mbrNo"] as! String
                        UserDefaults.standard.set(mbrNo, forKey: "mbrNo")
                        completion()
                        print("Success:")
                    }catch{
                        print("Error: ")
                    }
                }else {
                    print("Error: ")
                    return
                }
            case .failure(let error):
                print("Error: \(error)")
            }
        }   }catch{

        }
     
        
    }
    
    
    func cpAndGoPopUp(){
        let cmPopUp = CmPopUp()
        
        cmPopUp.delegate = self
        cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        cmPopUp.layer.cornerRadius = 10
        cmPopUp.layer.masksToBounds = true
        cmPopUp.popUpNm.text = "머니 비밀번호 변경이 완료되었습니다."
        cmPopUp.popUpCont.text = "E4.PAY의 다양한 혜택을 누려보세요."
        cmPopUp.yesBtn.isHidden = true
        cmPopUp.noBtn.isHidden = true
        cmPopUp.center = view.center
        
        //
        let topBorder = CALayer()
        topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.okBtn.frame.size.width, height: 0.5)
        topBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.okBtn.layer.addSublayer(topBorder)
        
        
        let darkBackgroundView = UIView(frame: view.bounds)
        darkBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        darkBackgroundView.alpha = 0
        view.addSubview(darkBackgroundView)
        
        
        // 팝업을 띄우기 위한 애니메이션
        cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        cmPopUp.alpha = 0
        view.addSubview(cmPopUp)
        
        UIView.animate(withDuration: 0.3) {
            darkBackgroundView.alpha = 1
            cmPopUp.alpha = 1
            cmPopUp.transform = CGAffineTransform.identity
            
        }
    }
    

    
    func loginApi( completion: @escaping (_ isCheck : Bool) -> Void ){
            
        var mbrNo = UserDefaults.standard.string(forKey: "mbrNo")

        if let stringValue = mbrNo, let intValue = Int(stringValue) {
       
        var data = ["mbrNo" : intValue , "monySertNo" : self.secretKeyVal] as [String:Any]
        
            let apiUrl = "http://192.168.10.150:48080/money/pwChk"

            let header: HTTPHeaders = [
                    "Content-Type": "application/json;charset=UTF-8"
                ]
                
        NetworkManager.shared.request(url: apiUrl, method: .get, parameters: data as Parameters, encoding: URLEncoding.default ,headers : header) { result in
                    switch result {
                    case .success(let value):
                        let data  = value as? [String : Any]
                        let data2 = data?["rpsCd"] as? String
                        if (data2 == "000"){
                                do {
                                    UserDefaults.standard.set(mbrNo, forKey: "mbrNo")
                                    completion(true)
                                    print("Success:")
                                }catch{
                                    print("Error: ")
                                }
                            }else {
                                print("Error: ")
                                return
                            }
                        
                case .failure(let error):
                    completion(false)
                    print("Error: \(error)")
                }
            }
            
        }
        
        else {
            print("멤버코드 추출 실패")
        }
    }

    
    
}

