//
//  mnCgCpViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit
import Alamofire

class mnCgCpViewCtr: UIViewController {

    
    @IBOutlet weak var bankNm: UILabel!
    
    @IBOutlet weak var acntNo: UILabel!
    
    @IBOutlet weak var myAmt: UILabel!
    
    @IBOutlet weak var container1: UIView!
    
    @IBOutlet weak var okBtn: UIButton!
    
    
    var bankNmVal : String?
    var acntNoVal  : String?
    var myAmtVal  : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        bankNm.text = bankNmVal
        acntNo.text = acntNoVal
        // Do any additional setup after loading the view.
        setUp()
    }
    
    func setUp(){
        getMnInfo()
        bankNm.text = bankNmVal
        acntNo.text = acntNoVal
        container1.layer.cornerRadius = 8
        container1.layer.cornerRadius = 8
     
    }

    @IBAction func goHome(_ sender: Any) {
        
        self.navigationController?.popToRootViewController(animated: true)
        
    }
    
    
    func getMnInfo() {
        
        let apiUrl = "http://192.168.10.150:48080/money/getpossible-money"
        let mbrNo  = UserDefaults.standard.string(forKey: "mbrNo")
        var param = ["mbrNo" : Int(mbrNo!)] as? [String : Any]
        let header: HTTPHeaders = [
                "Content-Type": "application/json;charset=UTF-8"
            ]
        
        NetworkManager.shared.request(url: apiUrl, method: .get,parameters: param , encoding: URLEncoding.default,headers: header) { result in
            switch result {
            case .success(let value):
                let data = value as? [String : Any]
                let data2 = data?["rpsCd"]
                if (data2 as? String == "000"){
                    let aMn = data?["usePossMony"] as? Int
                    self.myAmt.text = NumberUtil.shared.formatAmountWithoutDecimal(amount: aMn ?? 0) + "원"
                }else {
                  
                }
          
             
            case .failure(let error):
                print("Error: \(error)")
            }
        }
        
    }
    

}
