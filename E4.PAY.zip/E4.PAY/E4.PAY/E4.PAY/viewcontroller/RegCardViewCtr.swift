//
//  RegCardViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/16.
//

import UIKit

class RegCardViewCtr: UIViewController, UIGestureRecognizerDelegate ,SecretKeyDelegate, SideMenu, UITextFieldDelegate{
    func outputData(Str: String, inputIdx: Int) {
        if(selectCd == "2") {
            if Str == "초기화"{
                inputData2.removeAll()
                return
            }
            if Str == "back"{
                inputData2.removeLast()
                return
            }
            inputData2.append(Str)
            var cvInput = inputData2
            self.input2.text = cvInput
        }
        else if(selectCd == "3"){
            if Str == "초기화"{
                inputData3.removeAll()
                var cvInput = inputData3
                self.input3.text = cvInput
                return
            }
            if Str == "back"{
                inputData3.removeLast()
                var cvInput = inputData3
                self.input3.text = cvInput
                return
            }
            inputData3.append(Str)
            var cvInput = inputData3
            self.input3.text = cvInput
        }
    }
    
    func openSideMenu() {
        return
    }
    
    func goBack() {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    var inputData2 = ""
    var inputData3 = ""
    
    var selectCd = ""
    
    @IBOutlet weak var input1: UITextField!
    
    @IBOutlet weak var input2: UITextField!
    
    @IBOutlet weak var input3: UITextField!
    
    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var goNextBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        topBar.delegate = self
        setUp()
    }
    

    @IBAction func goNext(_ sender: Any) {
        
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "CardSecertViewCtr") as? CardSecertViewCtr else {return}
        self.navigationController?.pushViewController(pushVC, animated: true)
        
    }
    
    func setUp(){
        
        input1.addLeftPadding()
        input2.addLeftPadding()
        input3.addLeftPadding()
        input1.layer.cornerRadius = 8
        input2.layer.cornerRadius = 8
        input3.layer.cornerRadius = 8
        goNextBtn.layer.cornerRadius = 8
        
        
        
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        //let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped))
        //        tapGesture.delegate = self
        //        inputSec1.addGestureRecognizer(tapGesture)
        input2.isUserInteractionEnabled = true
        input3.isUserInteractionEnabled = true
        let keypad = KeypadView()
        keypad.delegate = self
        keypad.tag = 4
        keypad.frame = CGRect(x: 0, y: view.bounds.height - 360, width: view.bounds.width, height: 325)
        input2.inputView = keypad
        input3.inputView = keypad
        let tapOutsideGesture = UITapGestureRecognizer(target: self, action: #selector(outsideTapped))
        view.addGestureRecognizer(tapOutsideGesture)
    }
    
    @objc func outsideTapped(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: view)
        
        view.endEditing(true)

    }
    
    
    @IBAction func setSelectCd(_ sender: Any) {
        self.selectCd = "2"
    }
    
    @IBAction func setSelectCd2(_ sender: Any) {
        self.selectCd = "3"
    }
    
    

}
