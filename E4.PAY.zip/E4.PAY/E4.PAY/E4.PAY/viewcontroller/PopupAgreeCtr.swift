//
//  PopupAgreeCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/08.
//


import UIKit

class PopupAgreeCtr: UIViewController {
    
    @IBOutlet weak var agreeBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        }
    
    @IBAction func agreeClick(_ sender: Any) {
      
    }
    
    
}

