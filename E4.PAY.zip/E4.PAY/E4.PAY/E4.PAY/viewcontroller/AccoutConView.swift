//
//  SignUpView.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/09.
//

import UIKit
import Alamofire

class AccountConView: UIViewController, SendDataDelegate, SideMenu, UIGestureRecognizerDelegate {
    func openSideMenu() {
        return
    }
    
    func goBack() {
        if (self.navigationController != nil){
            self.navigationController?.popViewController(animated: true)
        }else{
            self.dismiss(animated: true)
        }
    }
    
    var logiCode : String = "1"
    var dtBankNm : String = ""
    var dtAccount : String = ""
    
    

    @IBOutlet weak var recBankNm: UITextField!
    @IBOutlet weak var recAccount: UITextField!
    @IBOutlet weak var recBankImg: UIImageView!
    @IBOutlet weak var topBar: TopBar!
    @IBOutlet weak var cpBankNm: UILabel!
    @IBOutlet weak var cpAccout: UILabel!
    @IBOutlet weak var acViewNextBtn: UIButton!
    @IBOutlet weak var nextBtnLb: UILabel!
    
    
    @IBOutlet weak var commentLb: UILabel!
    
    var instId = ""
    
 
    
    func sendData(bankNm: String, bankImg: UIImage , sdInstId  : String) {
        self.recBankNm.text = bankNm
        self.recBankImg.image = bankImg
        self.instId = sdInstId
    }
    
    @IBAction func goBankList(_ sender: Any) {
        
        let bankListView = self.storyboard?.instantiateViewController(identifier: "BankListView") as! BankListView
        bankListView.delegate = self
        
        if(logiCode == "3"){
            self.navigationController?.present(bankListView, animated: true)
        }
        
        if(logiCode == "1"){
            self.present(bankListView, animated: true)
        }
        
    }

    

    
    override func viewDidLoad() {
       
        super.viewDidLoad()
        self.topBar.delegate = self
        
        setUpView()
        
        
        }
    
    
    func setUpView() {
        if (self.logiCode == "1"){
            self.topBar.menuBtn.isHidden = true
        }
        if (self.logiCode == "2"){
            self.topBar.menuBtn.isHidden = true
            self.cpBankNm.text = self.dtBankNm
            self.cpAccout.text = self.dtAccount
        }
        
        if (self.logiCode == "3"){
            self.topBar.mainImage.isHidden = true
            self.topBar.menuBtn.isHidden = true
        }
        
        if (self.logiCode == "4"){
            self.topBar.mainImage.isHidden = true
            self.topBar.menuBtn.isHidden = true
            self.cpBankNm.text = self.dtBankNm
            self.cpAccout.text = self.dtAccount
            self.nextBtnLb.text = "확인"
        }
        
        recBankNm.layer.cornerRadius = 8
        recAccount.layer.cornerRadius = 8
        acViewNextBtn.layer.cornerRadius = 8
        recBankNm.addLeftPadding()
        recAccount.addLeftPadding()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(goBankList))
        tapGesture.delegate = self
        recBankNm.addGestureRecognizer(tapGesture)

        
        
        
    }
    
    
    
    @IBAction func okBtn(_ sender: Any) {
        guard let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AccountCompl") as? AccountConView else {return}
        
    
        if(logiCode == "1"){
            
            if ((self.recBankNm.text?.isEmpty) != true  &&  (self.recAccount.text?.isEmpty) != true){
                
                pushVC.logiCode = "2"
                pushVC.dtBankNm = self.recBankNm.text!
                pushVC.dtAccount = self.recAccount.text!
                pushVC.modalPresentationStyle = .fullScreen
                self.present(pushVC, animated: true)
                
                if let data = UserDefaults.standard.data(forKey: "usrInfo") {
                    do {
                        let decoder = JSONDecoder()
                        var loadedUserInfo = try decoder.decode(MbrInfo.self, from: data)
                        loadedUserInfo.acntNo = self.recAccount.text
                        loadedUserInfo.instId = self.instId
                        let encoder = JSONEncoder()
                        let data2 = try encoder.encode(loadedUserInfo)
                        UserDefaults.standard.set(data2 , forKey: "usrInfo")
                        
                    } catch {
                        
                    }
                } else {
                    
                }
                
                //if(inputB)
            }
            else {
                
                self.commentLb.text = "은행과 계좌번호를 확인해 주세요"
                return
                
            }
        }
            
            
            if(logiCode == "2"){
                
                guard let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecertKeyView") as? SecertKeyView else {return}
                pushVC.logicCode = "1"
                
                UserDefaults.standard.set(cpBankNm.text , forKey: "bankNm")
                
                pushVC.modalPresentationStyle = .fullScreen
                self.present(pushVC, animated: true)
            }
            
            if(logiCode == "3"){
                
                pushVC.logiCode = "4"
                pushVC.dtBankNm = self.recBankNm.text!
                pushVC.dtAccount = self.recAccount.text!
                joinAccount() { issuccess in
                    if issuccess == true {
                    let mainView = self.navigationController
                    mainView?.pushViewController(pushVC, animated: true)
                        }else {
                            //계좌 변경 실패 처리
                            return
                        }
                    }
            }
            
            
            if (logiCode == "4"){
        
                        self.navigationController?.popToRootViewController(animated: true)
             
            }
            
            
            
        
        
    }
    
    
    func joinAccount(completion: @escaping (_ isCheck : Bool) -> Void ) {
        
        let apiUrl = "http://192.168.10.150:48080/account/register"
        let mbrNo  = UserDefaults.standard.string(forKey: "mbrNo")
        var param = ["mbrNo" : mbrNo,  "instId":self.instId,"acntNo":(self.recAccount.text ?? "") ,"fsOrtEmpNo" : "fsOrtEmpNo" , "lsOrtEmpNo" : "lsOrtEmpNo" ] as? [String : Any]
        let header: HTTPHeaders = [
                "Content-Type": "application/json;charset=UTF-8"
            ]
        
        NetworkManager.shared.request(url: apiUrl, method: .post,parameters: param , encoding: JSONEncoding.default,headers: header) { result in
            switch result {
            case .success(let value):
                let data = value as? [String : Any]
                let data2 = data?["code"]
                if (data2 as? String == "0000"){
                    completion(true)
                }else {
                    completion(false)
                }
          
             
            case .failure(let error):
                print("Error: \(error)")
            }
        }
        
    }
    
    
    
}

