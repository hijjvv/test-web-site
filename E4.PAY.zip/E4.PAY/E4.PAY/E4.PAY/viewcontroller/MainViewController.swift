//
//  ViewController.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/10.
//

import UIKit
import Alamofire

class MainViewController: UIViewController {

    override func viewDidLoad() {
 
        super.viewDidLoad()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.getStart()
        }
        
        // Do any additional setup after loading the view.
    }
    
    
    func getStart() {
        guard let welcomeVC =  self.storyboard?.instantiateViewController(withIdentifier: "identiVerifCtr") as? UIViewController else {return}
            
//        welcomeVC.modalPresentationStyle = .fullScreen
//        self.present(welcomeVC, animated: true, completion: nil)
//
        
        checkUuid(){ isCheck in
            if isCheck == true{
                guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "PayMainPageView") as? UINavigationController else {return}

                self.dismiss(animated: true) {
                    pushVC.modalPresentationStyle = .fullScreen
                    self.present(pushVC, animated: true, completion: nil)
                }
            } else if isCheck == false{
                welcomeVC.modalPresentationStyle = .fullScreen
                self.present(welcomeVC, animated: true, completion: nil)
            }
        }
        
        
    }
    
    
    func checkUuid( completion: @escaping (_ isCheck : Bool) -> Void ){
            
        var uuid = UIDevice.current.identifierForVendor!.uuidString
        uuid.removeLast()
        uuid += "E"
        var data = ["uuid" : uuid]
        
            let apiUrl = "http://192.168.10.150:48080/member/checkuuid"

            let header: HTTPHeaders = [
                    "Content-Type": "application/json;charset=UTF-8"
                ]
                
                NetworkManager.shared.request(url: apiUrl, method: .get, parameters: data , encoding: URLEncoding.default ,headers : header) { result in
                switch result {
                case .success(let value):
                    let data = value as? [String : Any]
                    let data2 = data?["exsist"]
                    let mbrNo : String = data?["mbrNo"] as? String ?? ""
                    if (data2 as! Bool == true){
                        do {
                            UserDefaults.standard.set(mbrNo, forKey: "mbrNo")
                            completion(true)
                            print("Success:")
                        }catch{
                            print("Error: ")
                        }
                    }else {
                        completion(false)
                        print("Error: ")
                        return
                    }
                case .failure(let error):
                    completion(false)
                    print("Error: \(error)")
                }
            }
            
        }
        
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
