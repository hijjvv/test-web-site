
import Foundation
import UIKit


class SideMenuViewCtr: UIViewController,HeaderViewDelegate , UITableViewDataSource, UITableViewDelegate {
       

        @IBOutlet weak var menuTable: UITableView!
    
    
        var isOpen = [true,true]
        let numberList : [String] = ["1","2"]
        let sectionNm : [String] = ["머니","카드"]
        
        let moneyMenuList  = ["연결계좌변경", "충전", "환불","머니 이용내역", "머니 비밀번호 변경", "머니결제", "내 머니정보"]
        let cardMenuList  = ["카드 사용등록", "카드 결제",
                            "카드 분실신고/해제", "카드 비밀번호 변경", "카드 신청", "내카드 보기"]
        
        var menuList : [[String]] = [[]]

        
        
        
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
        
            //self.usrList.register( CustomHeaderView.self, forHeaderFooterViewReuseIdentifier: "CustomHeaderView")
            
            let headerNib = UINib(nibName: "Section", bundle: nil)
            menuTable.register(headerNib, forHeaderFooterViewReuseIdentifier: "customHeader")
            
            menuTable.sectionHeaderTopPadding = 15
            
            self.menuList.insert(self.moneyMenuList, at: 0)
            self.menuList.insert(self.cardMenuList, at: 1)
            
        }
        
     func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

        return 50.0
    }
        
        
    //    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
    //         // Header 영역 크기 = 140(separator 상단) + 12(separator 하단)
    //
    //         return 1
    //     }
        
        func didTouchSection(_ sectionIndex: Int) {
            self.isOpen[sectionIndex].toggle()
            self.menuTable.reloadSections(IndexSet(arrayLiteral: sectionIndex,sectionIndex), with: UITableView.RowAnimation.automatic)

        }
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return sectionNm.count
        }
        
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            if isOpen[section] == true{
                switch section {
                case 0 :
                    return moneyMenuList.count
                case 1 :
                    return cardMenuList.count
                default:
                    return 0
                  
                }
            } else{
                return 0
            }
            
        
        }
        

        
        func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            guard let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "customHeader") as? menuSection else { return UITableViewHeaderFooterView() }

              headerView.sectionIndex = section // 여기서 담아 줍니다.
            
            let target = sectionNm[section]
            headerView.labelt.text = target
            headerView.delegate = self
            headerView.isopened = isOpen[section]
              return headerView
          }
      



      

      
      
      
      //row의 형태
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

          let cell = menuTable.dequeueReusableCell(withIdentifier: "MenuTableCell", for : indexPath)as!
          MenuTableCell
          
          
          let target = menuList[indexPath.section][indexPath.row]
          
          cell.menuNm.text = target

          
          
          return cell
          
          
          
          
      }
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          // 선택한 셀의 내용 출력
         print("Selected item:" , menuList[indexPath.section][indexPath.row])
         var selectMenu = menuList[indexPath.section][indexPath.row]
         switch selectMenu {
             
            case "연결계좌변경" :
             
             guard let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AccountConView") as? AccountConView else {return}
             
             pushVC.logiCode = "3"
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
//             if let navigationController = self.navigationController {
//                 navigationController.setViewControllers([pushVC], animated: true)
//             }
         case "충전" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "ChargeViewCtr") as? ChargeViewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
         case "환불" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "DisCgViewCtr") as? DisCgViewCtr  else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
             
         case "머니 이용내역" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "mnUseListViewCtr") as? mnUseListViewCtr else {return}
             
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
         case "머니 비밀번호 변경" :
             guard let pushVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SecertKeyView") as? SecertKeyView else {return}
             pushVC.logicCode = "4"
//             self.navigationController?.pushViewController(pushVC, animated: true)
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
        
         case "머니결제" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "mnPayViewCtr") as? mnPayViewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
             
         case "내 머니정보" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "InfoMnViewCtr") as? InfoMnViewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
             
         case "카드 사용등록" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "RegCardViewCtr") as? RegCardViewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
             
         case "카드 결제" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "payViewCtr") as? UIViewController else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.present(pushVC, animated: true)
             }
         case "카드 비밀번호 변경" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "cgCardSecViewCtr") as? cgCardSecViewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
             
         case "카드 신청" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "SearchPostViewCtr") as? SearchPostViewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
         case "내카드 보기" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "CardInfoviewCtr") as? CardInfoviewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
             
         case "카드 분실신고/해제" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "CardInfoviewCtr") as? CardInfoviewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
        

             

             
       
             
            default :
             return
         }
         
      }


        

        
        
        
      
      
      
        
      
      
      

    }


//if let navigationController = self.navigationController,
//    let targetViewController = navigationController.viewControllers.first(where: { $0 is YourTargetViewControllerType }) {
//    navigationController.popToViewController(targetViewController, animated: true)
//}
//위의 코드에서 YourTargetViewControllerType은 스택에서 제거하려는 특정 뷰 컨트롤러의 타입에 해당하는 부분으로 대체해야 합니다. 이 코드는 네비게이션 스택에서 해당 뷰 컨트롤러로 이동하면서 그 사이에 있는 모든 뷰 컨트롤러를 제거합니다.
