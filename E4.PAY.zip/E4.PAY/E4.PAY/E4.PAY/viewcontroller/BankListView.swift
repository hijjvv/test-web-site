import UIKit
import Alamofire


protocol SendDataDelegate: AnyObject {
    func sendData(bankNm: String, bankImg : UIImage , sdInstId : String)
}



class BankListView: UIViewController, SendDataDelegate {
    func sendData(bankNm: String, bankImg: UIImage , sdInstId:String) {
    }
    
    
    
    weak var delegate: SendDataDelegate?
    // MARK: - Property
    
    
    
    var BankList : [BankDto] = []
    
    
    //let BankList = ["KDB산업","IBK기업","KB국민","수협","우리","SC","카카오","하나"]
//    let BankListImg = [UIImage(named: "KDB.png"),UIImage(named: "IBK.png"),UIImage(named: "KB.png"),UIImage(named: "SUH.png"),UIImage(named: "WORRI.png"),UIImage(named: "SC.png"),UIImage(named: "KAKAO.png"),UIImage(named: "hana.png")]
    
    // MARK: - View
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    
    
    override func viewDidLoad() {
        self.collectionView.collectionViewLayout = UICollectionViewFlowLayout()
        super.viewDidLoad()
        
        initialize()
        getBankList()
    }
    
    // MARK: - func
    func initialize() {

        collectionView?.delegate = self
        collectionView?.dataSource = self
    }
    
    
    func getBankList() {
        
        let apiUrl = "http://192.168.10.150:48080/account/list"
        
        NetworkManager.shared.request(url: apiUrl, method: .get , encoding: URLEncoding.default) { result in
            switch result {
            case .success(let value):
                let data = value as? [String : Any]
                let data2 = data?["response"]
                do {
                    let rdata = try JSONSerialization.data(withJSONObject: data2, options: .prettyPrinted)
                    let cfData = try JSONDecoder().decode([BankDto].self, from: rdata)
                    self.BankList = cfData
                    self.collectionView.reloadData()
                    print("Success: \(cfData)")
                }catch{
                    print("Error: ")
                }
             
            case .failure(let error):
                print("Error: \(error)")
            }
        }
        
    }

    
}


// MARK: - extension
extension BankListView: UICollectionViewDataSource {
    // MARK: cell count
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return BankList.count
    }
    
    // MARK: cell
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell: CustomCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "BankCell", for: indexPath) as? CustomCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        print(BankList[indexPath.item])

        cell.imageView?.image = UIImage(named: BankList[indexPath.item].instNm!)
        cell.label1?.text = BankList[indexPath.item].instNm
        
        return cell
    }
}

extension BankListView: UICollectionViewDelegate {
    
    // MARK: selected
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("\(indexPath.item)번 Cell 클릭")
        
//        let controller = self.storyboard?.instantiateViewController(identifier: "AccountConView") as! AccountConView
//       self.delegate = controller
        
        
        
        
        self.delegate?.sendData(bankNm: BankList[indexPath.item].instNm!, bankImg: UIImage(named: BankList[indexPath.item].instNm!)! , sdInstId : BankList[indexPath.item].instId!)
        print(BankList[indexPath.item])
        self.presentingViewController?.dismiss(animated: true, completion: nil)
        
    }
}

extension BankListView: UICollectionViewDelegateFlowLayout {
    
    // MARK: cellSize
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionViewWidth = collectionView.bounds.width
        let cellItemForRow: CGFloat = 3
        let minimumSpacing: CGFloat = 10
        
        let width = (collectionViewWidth - (cellItemForRow - 1) * minimumSpacing) / cellItemForRow
        
        return CGSize(width: width, height: width-14)
    }
    
    // MARK: minimumSpacing
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
}







