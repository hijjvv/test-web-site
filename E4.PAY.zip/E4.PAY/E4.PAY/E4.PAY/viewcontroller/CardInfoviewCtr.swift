
import Foundation
import UIKit


class CardInfoviewCtr: UIViewController,HeaderViewDelegate , UITableViewDataSource, UITableViewDelegate, SideMenu,CmPopUpProtocol {
    func clickYes() {
        reportLoss()
    
    }
    
    func clickNo() {
        hidePopup()
    }
    
    func clickOk() {
        hidePopup()

    }
    
    func openSideMenu() {
       return
    }
    
    func goBack() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
       

        @IBOutlet weak var menuTable: UITableView!
    
    
        var isOpen = [true,true]
        let numberList : [String] = ["1","2"]
        let sectionNm : [String] = ["카드설정","카드관리"]
        
        let cardSetting  = ["분실신고", "분실신고 해제"]
        let cardManage  = ["카드 비밀번호 변경", "사용 등록"]
        
        var menuList : [[String]] = [[]]
    
        let cmPopUp = CmPopUp()
        var logicCd = ""
        

    @IBOutlet weak var topBar: TopBar!
    
        
        
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
        
            //self.usrList.register( CustomHeaderView.self, forHeaderFooterViewReuseIdentifier: "CustomHeaderView")
            topBar.delegate = self
            topBar.menuBtn.isHidden = true
            
            let headerNib = UINib(nibName: "Section", bundle: nil)
            menuTable.register(headerNib, forHeaderFooterViewReuseIdentifier: "customHeader")
            
            menuTable.sectionHeaderTopPadding = 15
            
            self.menuList.insert(self.cardSetting, at: 0)
            self.menuList.insert(self.cardManage, at: 1)
            
          
            cmPopUp.delegate = self
            
        }
        
     func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {

        return 50.0
    }
        
        
    //    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
    //         // Header 영역 크기 = 140(separator 상단) + 12(separator 하단)
    //
    //         return 1
    //     }
        
        func didTouchSection(_ sectionIndex: Int) {
            self.isOpen[sectionIndex].toggle()
            self.menuTable.reloadSections(IndexSet(arrayLiteral: sectionIndex,sectionIndex), with: UITableView.RowAnimation.automatic)

        }
        
        func numberOfSections(in tableView: UITableView) -> Int {
            return sectionNm.count
        }
        
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            if isOpen[section] == true{
                switch section {
                case 0 :
                    return cardSetting.count
                case 1 :
                    return cardManage.count
                default:
                    return 0
                  
                }
            } else{
                return 0
            }
            
        
        }
        

        
        func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
            guard let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "customHeader") as? menuSection else { return UITableViewHeaderFooterView() }

              headerView.sectionIndex = section // 여기서 담아 줍니다.
            
            let target = sectionNm[section]
            headerView.labelt.text = target
            headerView.delegate = self
            headerView.isopened = isOpen[section]
              return headerView
          }
      



      

      
      
      
      //row의 형태
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

          let cell = menuTable.dequeueReusableCell(withIdentifier: "MenuTableCell", for : indexPath)as!
          MenuTableCell
          
          
          let target = menuList[indexPath.section][indexPath.row]
          
          cell.menuNm.text = target

          
          
          return cell
          
          
          
          
      }
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          // 선택한 셀의 내용 출력
         print("Selected item:" , menuList[indexPath.section][indexPath.row])
         var selectMenu = menuList[indexPath.section][indexPath.row]
         switch selectMenu {
             
         case "분실신고" :
             self.logicCd = "1"
             reportLossPopUp()
             
         case "분실신고 해제" :
             self.logicCd = "2"
             reportLossPopUp()
             
         case "충전" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "ChargeViewCtr") as? ChargeViewCtr else {return}
             let mainView = self.presentingViewController as? UINavigationController
             self.dismiss(animated: true){
                 mainView?.pushViewController(pushVC, animated: true)
             }
            
         case "카드 비밀번호 변경" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "cgCardSecViewCtr") as? cgCardSecViewCtr else {return}
             let mainView = self.navigationController
             mainView?.popViewController(animated: true)
             mainView?.pushViewController(pushVC, animated: true)
             
             
         case "사용 등록" :
             guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "RegCardViewCtr") as? RegCardViewCtr else {return}
             let mainView = self.navigationController
             mainView?.popViewController(animated: true)
             mainView?.pushViewController(pushVC, animated: true)
             
             

             

             
       
             
            default :
             return
         }
         
      }


        

//        
//    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
//          let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 18))
//          let lineView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 9))
//          footerView.addSubview(lineView)
//          lineView.backgroundColor = .lightGray.withAlphaComponent(0.1)
//          return footerView
//      }
        
      
      
    func reportLossPopUp(){
      
        
        self.cmPopUp.yesBtn.isHidden = false
        self.cmPopUp.noBtn.isHidden = false
        cmPopUp.okBtn.isHidden = true
        cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        cmPopUp.layer.cornerRadius = 10
        cmPopUp.layer.masksToBounds = true
        
        if(logicCd == "1"){
            
            cmPopUp.popUpNm.text = "분실신고를 하시겠습니까?"
            cmPopUp.popUpCont.text = "분실신고 즉시 해당 카드 사용이 정지됩니다.\n카드를찾으시면 언제든지 앱에서 분실해제\n가능합니다.\n카드 재발급은 앱에서 신청하실 수 있습니다."
        }
        
        if(logicCd == "2"){
            
            cmPopUp.popUpNm.text = "분실신고를 해제 하시겠습니까?"
            cmPopUp.popUpCont.text = "분실신고 해제 즉시 해당 카드를 사용하실 수 있습니다./n/n 고객센터문의(02-1234-5678)"
        }
   
        cmPopUp.center = view.center
        
        //
        let topBorder = CALayer()
        topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.yesBtn.frame.size.width, height: 0.5)
        topBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.noBtn.layer.addSublayer(topBorder)
        
        let topBorder2 = CALayer()
        topBorder2.frame = CGRect(x: 0, y: 0, width: cmPopUp.yesBtn.frame.size.width, height: 0.5)
        topBorder2.backgroundColor = UIColor.gray.cgColor
        cmPopUp.yesBtn.layer.addSublayer(topBorder2)

    
        
        let rightBorder = CALayer()
        rightBorder.frame = CGRect(x: cmPopUp.noBtn.bounds.width - 0.5, y: 0, width: 0.5, height: cmPopUp.yesBtn.bounds.height )
        rightBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.noBtn.layer.addSublayer(rightBorder)
        
        let darkBackgroundView = UIView(frame: view.bounds)
        darkBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        darkBackgroundView.alpha = 0
        darkBackgroundView.tag = 123
        view.addSubview(darkBackgroundView)
        

        
        
        
        // 팝업을 띄우기 위한 애니메이션
        
        cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        cmPopUp.alpha = 0
        view.addSubview(cmPopUp)
        
        UIView.animate(withDuration: 0.3) {
            darkBackgroundView.alpha = 1
            self.cmPopUp.alpha = 1
            self.cmPopUp.transform = CGAffineTransform.identity
            
        }
    }
    
    
    @objc func hidePopup() {
           // 팝업이 사라질 때 배경 어둡게 처리 해제
           if let darkBackgroundView = view.viewWithTag(123){
               UIView.animate(withDuration: 0.3, animations: {
                   darkBackgroundView.alpha = 0
               }) { (finished) in
                   if finished {
                       darkBackgroundView.removeFromSuperview()
                      
                   }
               }
           }

           // 팝업을 사라지게 하는 애니메이션
           UIView.animate(withDuration: 0.3, animations: {
               self.cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
               self.cmPopUp.alpha = 0
           }) { (finished) in
               if finished {
                   self.cmPopUp.removeFromSuperview()
                   self.cmPopUp.transform = CGAffineTransform.identity

               }
           }
       }
    
    
    func reportLoss(){
        
        if let darkBackgroundView = view.viewWithTag(123){
            UIView.animate(withDuration: 0.3, animations: {
                darkBackgroundView.alpha = 0
            }) { (finished) in
                if finished {
                    darkBackgroundView.removeFromSuperview()
                    
                }
            }
        }
        
        cmPopUp.okBtn.isHidden = false
        cmPopUp.yesBtn.isHidden = true
        cmPopUp.noBtn.isHidden = true
        cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        cmPopUp.layer.cornerRadius = 10
        cmPopUp.layer.masksToBounds = true
        
        if(logicCd == "1"){
            cmPopUp.popUpNm.text = "분실신고를 완료하였습니다."
            cmPopUp.popUpCont.text = "분실신고한 카드는 사용할 수 없습니다."
        }
        if(logicCd == "2"){
            cmPopUp.popUpNm.text = "분실신고 해제를 완료하였습니다.."
            cmPopUp.popUpCont.text = "분실신고 해제 즉시 해당 카드를 사용하실 수 있습니다."
        }
   
        cmPopUp.center = view.center
        
        //
        let topBorder = CALayer()
        topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.yesBtn.frame.size.width, height: 0.5)
        topBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.noBtn.layer.addSublayer(topBorder)
        
        let topBorder2 = CALayer()
        topBorder2.frame = CGRect(x: 0, y: 0, width: cmPopUp.yesBtn.frame.size.width, height: 0.5)
        topBorder2.backgroundColor = UIColor.gray.cgColor
        cmPopUp.yesBtn.layer.addSublayer(topBorder2)

    
        
        let rightBorder = CALayer()
        rightBorder.frame = CGRect(x: cmPopUp.noBtn.bounds.width - 0.5, y: 0, width: 0.5, height: cmPopUp.yesBtn.bounds.height )
        rightBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.noBtn.layer.addSublayer(rightBorder)
        
        let darkBackgroundView = UIView(frame: view.bounds)
        darkBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        darkBackgroundView.alpha = 0
        darkBackgroundView.tag = 123
        view.addSubview(darkBackgroundView)
        

        
        
        
        // 팝업을 띄우기 위한 애니메이션
        
        cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        cmPopUp.alpha = 0
        view.addSubview(cmPopUp)
        
        UIView.animate(withDuration: 0.3) {
            darkBackgroundView.alpha = 1
            self.cmPopUp.alpha = 1
            self.cmPopUp.transform = CGAffineTransform.identity
            
        }
        

        self.logicCd = ""
    }
    
    
        
      
      
      

    }


//if let navigationController = self.navigationController,
//    let targetViewController = navigationController.viewControllers.first(where: { $0 is YourTargetViewControllerType }) {
//    navigationController.popToViewController(targetViewController, animated: true)
//}
//위의 코드에서 YourTargetViewControllerType은 스택에서 제거하려는 특정 뷰 컨트롤러의 타입에 해당하는 부분으로 대체해야 합니다. 이 코드는 네비게이션 스택에서 해당 뷰 컨트롤러로 이동하면서 그 사이에 있는 모든 뷰 컨트롤러를 제거합니다.
