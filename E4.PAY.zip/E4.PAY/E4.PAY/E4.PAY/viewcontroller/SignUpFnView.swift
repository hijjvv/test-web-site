//
//  SignUpFnView.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/10.
//

import UIKit

class SignUpFnView: UIViewController, SideMenu {
    

    func openSideMenu() {
        return
    }
    
    func goBack() {
        if (self.navigationController != nil){
            self.navigationController?.popViewController(animated: true)
        }else{
            self.dismiss(animated: true)
        }
    }
    
    
    @IBOutlet weak var userNm: UILabel!
    
    @IBOutlet weak var userPnb: UILabel!
    
    @IBOutlet weak var userBankNm: UILabel!
    
    @IBOutlet weak var userAccount: UILabel!
    
    
    @IBOutlet weak var topBar: TopBar!
    
    var signUpData : MbrInfo = MbrInfo()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        topBar.backBtn.isHidden = true
        
        userNm.text = signUpData.mbrNm
        userPnb.text = signUpData.hpNo
        userAccount.text = signUpData.acntNo
        userBankNm.text  = UserDefaults.standard.string(forKey: "bankNm")
        
        // Do any additional setup after loading the view.
    }
    
    

    @IBAction func goPayMain(_ sender: Any) {
        
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "PayMainPageView") as? UINavigationController else {return}
        
//        guard let pvc = self.presentingViewController else { return }
//
//        self.presentingViewController?
//            .dismiss(animated: true) {
//          pushVC.modalPresentationStyle = .fullScreen
//          pvc.present(pushVC, animated: true, completion: nil)
//        }
        
     
//        self.view.window?.rootViewController?.dismiss(animated: false, completion: {
//            let pushVC = PayMainPageView()
//            pushVC.modalPresentationStyle = .fullScreen
//          let appDelegate = UIApplication.shared.delegate as! AppDelegate
//          appDelegate.window?.rootViewController?.present(homeVC, animated: true, completion: nil)
//        })
        
//        let navigationController = pushVC
//        UIApplication.shared.windows.first?.rootViewController = navigationController
//        UIApplication.shared.windows.first?.makeKeyAndVisible()
//
//        UIApplication.shared.keyWindow?.rootViewController?.dismiss(animated: false, completion: nil)
//
//        guard let pvc = self.presentingViewController else { return }
//            self.dismiss(animated: true) {
//                // 새로운 UINavigationController으로 이동
//                //let secondNavigationController = UINavigationController(rootViewController: pushVC)
//
//                // present 메서드를 사용하여 새로운 UINavigationController을 띄우기
//                pushVC.modalPresentationStyle = .fullScreen
//                pvc.present(pushVC, animated: true, completion: nil)
//            }
        
        UIApplication.shared.keyWindow?.rootViewController?.dismiss(animated: false) {
            // 닫힌 후에 실행될 코드입니다.

            pushVC.modalPresentationStyle = .fullScreen
            UIApplication.shared.keyWindow?.rootViewController?.present(pushVC, animated: true, completion: nil)
        }
        
        
        
//        guard let rootview = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "rootView") as? UIViewController else {return}
//
//
//        if let navigationController = self.navigationController {
//            navigationController.setViewControllers([pushVC], animated: true)
//        }


        
//        pushVC.modalPresentationStyle = .fullScreen
//        self.present(pushVC, animated: true, completion: {
//            // 현재 UINavigationController를 닫기 (dismiss)
//            if let currentNavController = self.navigationController {
//                currentNavController.dismiss(animated: true, completion: nil)
//            }
//        })
        

        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func dismissPreviousViewControllers() {
         self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
         self.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
         self.presentingViewController?.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
         self.presentingViewController?.presentingViewController?.presentingViewController?.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
     }

}
