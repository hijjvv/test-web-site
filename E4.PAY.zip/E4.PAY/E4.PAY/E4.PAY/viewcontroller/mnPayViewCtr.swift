//
//  mnPayViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import UIKit

class mnPayViewCtr: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout, SideMenu {
    func openSideMenu() {
     return
    }
    
    func goBack() {
        if (self.navigationController != nil){
            self.navigationController?.popViewController(animated: true)
        }else{
            self.dismiss(animated: true)
        }
    }
    


    @IBOutlet weak var ctgrClVeiw: UICollectionView!
    
    @IBOutlet weak var gdTbView: UITableView!
    
    
    
    @IBOutlet weak var topBar: TopBar!
    
    let sectionNm : [String] = ["E4베이커리","E4Coffee","C가맹점","B가맹점","F가맹점"]
    
    var selectNo : Int = 0
    
    var startCd : String = ""
    
    let dataList : [GdDto] = [GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd1")!, gdAmt: "15,000",gdCtgr: "E4베이커리"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd2")!, gdAmt: "15,000",gdCtgr: "E4베이커리"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd3")!, gdAmt: "15,000",gdCtgr: "E4Coffee"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "E4Coffee"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "E4Coffee"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "C가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "C가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "C가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "C가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "B가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "B가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "B가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "B가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "F가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "F가맹점"),
                              GdDto(gdNm: "스타벅스원두커피", gdImg: UIImage(named: "gd4")!, gdAmt: "15,000",gdCtgr: "F가맹점"),
                              
    ]
    var filterData : [GdDto] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        if let layout = ctgrClVeiw.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        let topBorder = CALayer()
        let borderWidth: CGFloat = 1
        topBorder.frame = CGRect(x: 0, y: ctgrClVeiw.frame.size.height - 1, width: ctgrClVeiw.frame.size.width, height: 1)
        topBorder.backgroundColor = UIColor.systemGray6.cgColor
        ctgrClVeiw.layer.addSublayer(topBorder)

        
        dataFilter()
        
        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sectionNm.count // 아이템 개수
       }

       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mnUseCtgrCell", for: indexPath) as! mnUseCtgrCell

           if (startCd == ""){
               cell.isSelected = true
               collectionView.selectItem(at: indexPath, animated: false, scrollPosition: .init())
               cell.titleLabel.textColor = UIColor(hex: 0x141726)
               startCd = "clear"
           }else {
               
               cell.titleLabel.text = sectionNm[indexPath.item]
           }
           

           // 셀의 내용 설정

           return cell
       }
     func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // 선택된 셀의 배경색 변경
        if let selectedCell = collectionView.cellForItem(at: indexPath) as? mnUseCtgrCell {
            selectedCell.titleLabel.textColor = UIColor(hex: 0x141726)
        }
         self.selectNo = indexPath.item
         filterData.removeAll()
         dataFilter()
         self.gdTbView.reloadData()
         
         
    }

     func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        // 선택이 해제된 셀의 배경색 원래대로 변경
        if let deselectedCell = collectionView.cellForItem(at: indexPath) as? mnUseCtgrCell {
            deselectedCell.titleLabel.textColor = UIColor.systemGray6// 또는 다른 기본 색상
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {


                return CGSize(width: 120, height: 45)
                
        }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension mnPayViewCtr : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = gdTbView.dequeueReusableCell(withIdentifier: "mnPayGdTbCell", for : indexPath)as!
        mnPayGdTbCell
        
       
        
        
   

        cell.gdNm?.text = filterData[indexPath.item].gdNm
                cell.gdImg?.image = filterData[indexPath.item].gdImg
                cell.gdAmt?.text = filterData[indexPath.item].gdAmt
        cell.gdCtgr = filterData[indexPath.item].gdCtgr
        cell.buttonHandler = {
            // 버튼 탭 시 실행되는 클로저
             let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "OrderViewCtr") as? OrderViewCtr
            pushVC?.data.gdNm = cell.gdNm?.text!
            pushVC?.data.gdImg = cell.gdImg?.image!
            pushVC?.data.gdAmt = cell.gdAmt?.text!
            pushVC?.data.gdCtgr = cell.gdCtgr
            self.navigationController?.pushViewController(pushVC!, animated: true)
        }
                return cell
            
           
        
    }
    
        
        
    
    
    func rowNumCheck() -> Int{
        var rowNum = 0
        for  i in 0..<dataList.count{
            if (self.sectionNm[selectNo] == dataList[i].gdCtgr) {
                rowNum += 1
            }
        }
        return rowNum
    }
    

    func dataFilter(){

            for  i in 0..<dataList.count {
                var selectCtgr = sectionNm[self.selectNo]
                if (selectCtgr == dataList[i].gdCtgr) {
                    self.filterData.append(dataList[i])
            }
        }
    }
    
    
    
    
    
        
    
}
