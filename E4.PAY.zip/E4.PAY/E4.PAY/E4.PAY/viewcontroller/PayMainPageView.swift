//
//  PayMainPageView.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/10.
//

import UIKit

class PayMainPageView: UIViewController, SideMenu, PayMainProtocol {
    

    
    

    
    @IBOutlet weak var labelCtn1: UIButton!
    @IBOutlet weak var labelCtn2: UIButton!
    @IBOutlet weak var container2: UIView!
    @IBOutlet weak var container1: UIButton!
    @IBOutlet weak var containerMV: UIView!
    
    @IBOutlet weak var cardView: UIView!
    
    @IBOutlet weak var topBar: TopBar!
    
    var cardYn : String = "1"
    
    @IBOutlet weak var cardNm: UILabel!
    
    @IBOutlet weak var cardImg: UIImageView!
    
    @IBOutlet weak var cardNo: UILabel!
    
    @IBOutlet weak var cardCp: UILabel!
    
    @IBOutlet weak var cardRegDt: UILabel!
    
    @IBOutlet weak var mbrMn: UILabel!
    
    @IBOutlet weak var chBtn: UIButton!
    
    @IBOutlet weak var payLb: UILabel!
    
    var payMainPresenter: PayMainPresenter!
    
 
    
    func openSideMenu() {
        guard let pushVC = storyboard?.instantiateViewController(withIdentifier: "CustomSideMenuNavigation") else {
            return
        }
        self.present(pushVC, animated: true)
        //self.present(pushVC, animated: true, completion: nil)
    }
    
    func goBack() {
        self.presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    
    let label = UILabel()
    
    let cButton = UIButton()

    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.topBar.delegate = self
        self.topBar.backBtn.isHidden = true
        // Do any additional setup after loading the view.
        // 특정 뷰에 UILabel 추가
        setUpView()
        

      

    }
    
    override func viewDidAppear(_ animated: Bool) {
        payMainPresenter.getMbrInfo()
    }
    
    func setUpView(){


        
        
         let payMainService = PayMainService()
        payMainPresenter = PayMainPresenter(payMainService: payMainService)
        payMainPresenter.view = self
        payMainPresenter.getMbrInfo()

        containerMV.layer.cornerRadius = 8
        chBtn.layer.cornerRadius = 8
        container1.layer.cornerRadius = 8
        cardView.layer.cornerRadius = 8
        container2.layer.cornerRadius = 8
        
        labelCtn1.layer.cornerRadius = 8
        labelCtn1.layer.borderColor = UIColor.systemGray5.cgColor
        labelCtn1.layer.borderWidth = 0.4
        labelCtn1.layer.cornerRadius = 8.0
        labelCtn1.layer.masksToBounds = true
        
        labelCtn2.layer.cornerRadius = 8
        labelCtn2.layer.borderColor = UIColor.systemGray5.cgColor
        labelCtn2.layer.borderWidth = 0.4
        labelCtn2.layer.cornerRadius = 8.0
        labelCtn2.layer.masksToBounds = true

    }
    
    
    func setDataPayMain(data: ResMbrInfo) {
     
        var money = NumberUtil.shared.formatAmountWithoutDecimal(amount: (data.usePossMony ?? 0)  as Int)
        self.mbrMn.text = money + " 원"

        
        UserDefaults.standard.set(data.mbrNo, forKey: "mbrNo")
        UserDefaults.standard.set(data.usePossMony, forKey: "usePossMony")
        UserDefaults.standard.set(data.acntInfo?.acntNo, forKey: "acntNo")
        UserDefaults.standard.set(data.acntInfo?.instNm, forKey: "instNm")
        
       // if (data.cardExstYn == "y"){ 카드 있다고 가정하여
        if (1 == 1){
            //payMainPresenter.getCardInfo() pstmm api 호출제한으로 막음
            setCardDataPayMain()
            self.cardYn = "2"
            //카드정보 api 호출
        }else  {
            if (cardYn == "1"){
                cardCp.isHidden = true
                cardNo.isHidden = true
                cardImg.isHidden = true
                cardRegDt.isHidden = true
                cardView.addSubview(label)
                cardView.addSubview(cButton)
                payLb.text = "E4.PAY 가맹점 혜택을 누리세요!"
                layoutSetUp()
            }
        }
        
    }
    
    // 목데이터
    func setCardDataPayMain() {
        
        self.cardNm.text = "E4.PAY 체리 선불카드"
        self.cardNo.text = "5238-1534-1624"
        self.cardRegDt.text = "2024-01-03"
        self.cardCp.text = "2026-03-03"
        self.cardImg.image =  UIImage(named: "card-img.png")
        
        UserDefaults.standard.set("E4.PAY 체리 선불카드" , forKey: "cardNm")
        UserDefaults.standard.set("5238-1534-1624", forKey: "cardNo")
        UserDefaults.standard.set("2024-01-03", forKey: "isueDt")
        UserDefaults.standard.set("2026-03-03", forKey: "isueTm")
        UserDefaults.standard.set("card-img.png", forKey: "cardImg")
    }
    
    func setCardDataPayMain(data: ResCardInfo) {
        
        self.cardNm.text = "E4.PAY 체리 선불카드"
        self.cardNo.text = data.cardNo
        self.cardRegDt.text = data.isueDt
        self.cardCp.text = data.isueTm
        
        DispatchQueue.main.async{
            guard let url = URL(string: data.imgUrl ?? "") else { return  }
            if let data = (try? Data(contentsOf: url)) {
                self.cardImg.image =  UIImage(data: data)
            }
        }
        
        
        UserDefaults.standard.set("E4.PAY 체리 선불카드" , forKey: "cardNm")
        UserDefaults.standard.set(data.cardNo, forKey: "cardNo")
        UserDefaults.standard.set(data.isueDt, forKey: "isueDt")
        UserDefaults.standard.set(data.isueTm, forKey: "isueTm")
        UserDefaults.standard.set(data.imgUrl, forKey: "cardImg")
        
        
    }
    
    func displayError(message : String) {
    }

    
    func layoutSetUp(){

        
        
        label.text = "보유하신 카드가 없습니다.\n카드 신청하러 가기"
        label.textColor = UIColor.white
        label.font = .systemFont(ofSize: 17)
        label.textAlignment = .left
        label.translatesAutoresizingMaskIntoConstraints = false
        label.numberOfLines = 0 // 여러 줄 허용
        label.heightAnchor.constraint(equalToConstant: 50).isActive = true // 높이
        label.centerYAnchor.constraint(equalTo: cardView.centerYAnchor, constant: 15).isActive = true
        label.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 20).isActive = true // 높이

        
        cButton.setTitle("카드신청", for: .normal)
        cButton.titleLabel?.font = .systemFont(ofSize: 19)
        cButton.layer.cornerRadius = 8
        cButton.setTitleColor(UIColor.white, for: .normal)
        cButton.backgroundColor = UIColor(hex: 0xFF725E)
        cButton.translatesAutoresizingMaskIntoConstraints = false
        cButton.heightAnchor.constraint(equalToConstant: 50).isActive = true // 높이
        cButton.widthAnchor.constraint(equalToConstant: 90).isActive = true
        cButton.centerYAnchor.constraint(equalTo: cardView.centerYAnchor, constant: 15).isActive = true
        cButton.leadingAnchor.constraint(equalTo: label.trailingAnchor, constant: 20).isActive = true // 높이
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    @IBAction func goCgView(_ sender: Any) {
    
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "ChargeViewCtr") as? ChargeViewCtr else {return}
        
        self.navigationController?.pushViewController(pushVC, animated: true)
    }
    

    func viewlayoutSetUp(){
        
    }
    
}
