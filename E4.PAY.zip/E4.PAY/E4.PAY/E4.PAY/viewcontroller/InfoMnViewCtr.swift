//
//  InfoMnViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/16.
//

import UIKit

class InfoMnViewCtr: UIViewController, SideMenu {
    func openSideMenu() {
        
    }
    
    func goBack() {
        self.navigationController?.popViewController(animated: true)
        
    }
    

    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var goCgBtn: UIButton!
    
    @IBOutlet weak var bankNm: UILabel!
    
    @IBOutlet weak var acntLb: UILabel!
    
    @IBOutlet weak var mnLb: UILabel!
    
    @IBOutlet weak var payBtn: UIButton!
    
    @IBOutlet weak var container1: UIView!
    
    @IBOutlet weak var container2: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        setUpView()
        // Do any additional setup after loading the view.
    }
    
    func setUpView(){
        

        var getMn = UserDefaults.standard.string(forKey: "usePossMony") ?? "0"
        var money = NumberUtil.shared.formatAmountWithoutDecimal(amount: (Int(getMn) ?? 0)  as Int)
        bankNm.text = UserDefaults.standard.string(forKey: "instNm")
        mnLb.text   = UserDefaults.standard.string(forKey: "usePossMony")
        acntLb.text = UserDefaults.standard.string(forKey: "acntNo")
        

        self.mnLb.text = money + " 원"
        
        container1.layer.cornerRadius = 8
        container2.layer.cornerRadius = 8
        goCgBtn.layer.cornerRadius = 8
    }
  
    
    @IBAction func goCharge(_ sender: Any) {
        
        let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "ChargeViewCtr") as? ChargeViewCtr
    
        self.navigationController?.popViewController(animated: true)

        // 새로운 뷰 컨트롤러를 생성

        // 새로운 뷰 컨트롤러를 push
        self.navigationController?.pushViewController(pushVC!, animated: true)
        
    }
    
    
    @IBAction func goQrPay(_ sender: Any) {
        
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "payViewCtr") as? UIViewController else {return}
        
        self.navigationController?.present(pushVC, animated: true)
        
    }
    
    
    
    
}
