//
//  CardSecretViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/16.
//

//
//  SecretKeyView.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/09.
//

import UIKit


class RegiNumViewCtr :  UIViewController , SecretKeyDelegate, SideMenu, CmPopUpProtocol {
    func clickYes() {
        return
    }
    
    func clickNo() {
   
    }
    
    func clickOk() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    func openSideMenu() {
        return
    }
    
    func goBack() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    @IBOutlet weak var inputField: RegiNum!

    @IBOutlet weak var secretKey: KeypadView!
    
    
    @IBOutlet weak var topBar: TopBar!
    
    
    var logicCode = ""
    
    var secretKeyVal : String = ""
    
    func outputData(Str: String , inputIdx : Int) {
        
        if (Str == "back"){
        inputField.labelList[inputIdx].backgroundColor = UIColor(hex: 0xD1D1D6)
            secretKeyVal.removeLast()
            return
        }
        
        if (Str == "초기화"){
            for i in 0..<inputField.labelList.count {
                inputField.labelList[i].backgroundColor = UIColor(hex: 0xD1D1D6)
            }

            secretKeyVal.removeAll()
            return
        }
        
    
        inputField.labelList[inputIdx].backgroundColor = UIColor(hex: 0x000000)
        secretKeyVal += Str
        
        if (secretKeyVal.count == 13){
           return
        }
        

        
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        secretKey.delegate = self
        topBar.delegate = self
        topBar.menuBtn.isHidden = true

        
        }
    
    


    
  
    
    @IBAction func okAtion(_ sender: Any) {
        
        guard let pushVC = UIStoryboard(name: "PAYMAIN", bundle: nil).instantiateViewController(withIdentifier: "RegiCardSecViewCrt") as? RegiCardSecViewCrt else {return}
        self.navigationController?.pushViewController(pushVC, animated: true)
        
        
    }
    
    
    
}

