//
//  RegCardSecViewCtr.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/16.
//

import UIKit

class RegiCardSecViewCrt: UIViewController, UIGestureRecognizerDelegate ,SecretKeyDelegate, SideMenu, UITextFieldDelegate, CmPopUpProtocol {
    func clickYes() {
      return
    }
    
    func clickNo() {
        return
    }
    
    func clickOk() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    func outputData(Str: String, inputIdx: Int) {
        
        if(selectCd == "1") {
            if Str == "초기화"{
                inputData1.removeAll()
                return
            }
            if Str == "back"{
                inputData1.removeLast()
                return
            }
            inputData1.append(Str)
            var cvInput = inputData1
            self.inputSec1.text = cvInput
        }
        
        if(selectCd == "2") {
            if Str == "초기화"{
                inputData2.removeAll()
                return
            }
            if Str == "back"{
                inputData2.removeLast()
                return
            }
            inputData2.append(Str)
            var cvInput = inputData2
            self.inputSec2.text = cvInput
        }
    }
    
    func openSideMenu() {
        return
    }
    
    func goBack() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    
    
    var inputData1 = ""
    var inputData2 = ""
    var inputData3 = ""
    
    var selectCd = ""

    
    @IBOutlet weak var inputSec1: UITextField!
    
    @IBOutlet weak var inputSec2: UITextField!
    
    @IBOutlet weak var goBtn: UIButton!
    
    @IBOutlet weak var topBar: TopBar!
    
    @IBOutlet weak var commentLb: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        topBar.delegate = self
        inputSec1.delegate = self
        setUp()
        
        // Do any additional setup after loading the view.
    }
    
    
    func setUp(){
        inputSec1.addLeftPadding()
        inputSec2.addLeftPadding()
        inputSec1.layer.cornerRadius = 8
        inputSec2.layer.cornerRadius = 8
        goBtn.layer.cornerRadius = 8
        
        topBar.delegate = self
        topBar.menuBtn.isHidden = true
        //let tapGesture = UITapGestureRecognizer(target: self, action: #selector(labelTapped))
        //        tapGesture.delegate = self
        //        inputSec1.addGestureRecognizer(tapGesture)
        inputSec1.isUserInteractionEnabled = true
        let keypad = KeypadView()
        keypad.delegate = self
        keypad.frame = CGRect(x: 0, y: view.bounds.height - 360, width: view.bounds.width, height: 325)
        keypad.tag = 4
        inputSec1.inputView = keypad
        inputSec2.inputView = keypad
        
        let tapOutsideGesture = UITapGestureRecognizer(target: self, action: #selector(outsideTapped))
        view.addGestureRecognizer(tapOutsideGesture)
    }
    
    
    @objc func outsideTapped(_ sender: UITapGestureRecognizer) {
        let location = sender.location(in: view)
        
        view.endEditing(true)

    }
    
    @IBAction func scsCgSec(_ sender: Any) {
        
        scsCgSec()

    }
    
    @IBAction func setSelectCd1(_ sender: Any) {
        self.selectCd = "1"
    }
    
    @IBAction func setSelectCd2(_ sender: Any) {
        self.selectCd = "2"
    }
    
    func scsCgSec(){
        let cmPopUp = CmPopUp()
        
        cmPopUp.delegate = self
        cmPopUp.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
        cmPopUp.layer.cornerRadius = 10
        cmPopUp.layer.masksToBounds = true
        cmPopUp.popUpNm.text = "카드 신청이 완료되었습니다."
        cmPopUp.popUpCont.text = "E4.PAY의 다양한 혜택을 누려보세요."
        cmPopUp.yesBtn.isHidden = true
        cmPopUp.noBtn.isHidden = true
        cmPopUp.center = view.center
        
        //
        let topBorder = CALayer()
        topBorder.frame = CGRect(x: 0, y: 0, width: cmPopUp.okBtn.frame.size.width, height: 0.5)
        topBorder.backgroundColor = UIColor.gray.cgColor
        cmPopUp.okBtn.layer.addSublayer(topBorder)
        
        
        let darkBackgroundView = UIView(frame: view.bounds)
        darkBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        darkBackgroundView.alpha = 0
        view.addSubview(darkBackgroundView)
        

        
        
        
        // 팝업을 띄우기 위한 애니메이션
        cmPopUp.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
        cmPopUp.alpha = 0
        view.addSubview(cmPopUp)
        
        UIView.animate(withDuration: 0.3) {
            darkBackgroundView.alpha = 1
            cmPopUp.alpha = 1
            cmPopUp.transform = CGAffineTransform.identity
            
        }
    }
    
    
    
    
//}
    

}
