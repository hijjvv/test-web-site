//
//  Api.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/18.
//

//{
//  "rpsCatgCd": "정상",
//  "rpsCd": "000",
//  "rpsMsg": "정상 처리되었습니다.",
//  "mbrNo": "39"
//}

//{
//  "code": "CMN9999",
//  "message": "이미 존재하는 회원입니다.",
//  "timestamp": "20240118160411",
//  "errors": null
//}


import Foundation
import Alamofire

enum APIError: Error {
    case invalidResponse
    case requestFailed
    // 다른 에러 케이스들 추가 가능
}

class NetworkManager {

    static let shared = NetworkManager()
    
    private init() {}

    typealias CompletionHandler<T> = (Result<Any, APIError>) -> Void

    func request(
        url: URLConvertible,
        method: HTTPMethod = .get,
        parameters: Parameters? = nil,
        encoding: ParameterEncoding = JSONEncoding.default,
        headers: HTTPHeaders? = nil,
        completionHandler: @escaping CompletionHandler<Any>
    ) {
        AF.request(url, method: method, parameters: parameters, encoding: encoding , headers: headers)
            .validate(statusCode: 200..<400)
            .responseJSON{ response in
                switch response.result {
                case .success(let value):
                    let data = value as? [String : Any]
                    completionHandler(.success(data))
                case .failure(let error):
                    if let statusCode = response.response?.statusCode {
                        print("HTTP Status Code: \(statusCode)")
                    }
                    completionHandler(.failure(.requestFailed))
                }
            }
    }
}



