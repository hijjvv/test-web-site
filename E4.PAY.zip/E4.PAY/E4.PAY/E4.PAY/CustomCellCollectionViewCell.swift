//
//  CustomCellCollectionViewCell.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/09.
//

import UIKit

class CustomCellCollectionViewCell: UICollectionViewCell {
    
}
