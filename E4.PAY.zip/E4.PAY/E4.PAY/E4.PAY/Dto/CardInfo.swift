//
//  CardInfo.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/29.
//

import Foundation

struct ResCardInfo : Codable{
    var imgUrl : String?
    var ataCardNo: String?
    var cardNo: String?
    var brndClCd: String?
    var isueDt: String?
    var isueTm: String?
    var cardSt : String?
    var cardStCd :String?
}
