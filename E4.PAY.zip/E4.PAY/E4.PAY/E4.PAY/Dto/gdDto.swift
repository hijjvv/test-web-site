//
//  gdDto.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import Foundation
import UIKit

class GdDto{
    
    init(gdNm:String,gdImg:UIImage,gdAmt:String, gdCtgr : String){
        self.gdNm = gdNm
        self.gdImg = gdImg
        self.gdAmt = gdAmt
        self.gdCtgr = gdCtgr
    }
    
    var gdNm : String?
    var gdImg : UIImage?
    var gdAmt : String?
    var gdCtgr: String?
    

    
}
