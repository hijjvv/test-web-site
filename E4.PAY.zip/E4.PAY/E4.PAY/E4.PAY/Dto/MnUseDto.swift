//
//  mnUseList.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/15.
//

import Foundation

class MnUseDto {
    

    var regDt  : String = ""
    var gdNm   : String = ""
    var payAmt : String = ""
    var mnCd   : String = ""
    
    init(regDt : String , gdNm : String, payAmt : String, mnCd : String){
        
        self.regDt = regDt
        self.gdNm = gdNm
        self.payAmt = payAmt
        self.mnCd = mnCd
   }
}
