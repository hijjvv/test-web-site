//
//  ResMbrInfo.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/19.
//

import Foundation

struct ResMbrInfo : Codable{
    var rpsCatgCd : String?
      var rpsCd: String?
      var rpsMsg: String?
      var mbrNo: String?
      var mbrNm: String?
      var hpNo: String?
    var usePossMony : Int?
    var acntExstYn :String?
      var acntInfo : AcntInfo?
      var cardExstYn: String?
      var cardInfo : String?
    
    
}

struct AcntInfo : Codable{
    
    var regAcntSno : String?
    var acntNo : String?
    var instClCd : String?
    var instCd : String?
    var instNm : String?
    var imgUrl : String?
    var imgNm : String?
}
