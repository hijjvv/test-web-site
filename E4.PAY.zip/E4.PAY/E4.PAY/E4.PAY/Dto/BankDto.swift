//
//  BankDto.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/17.
//

import Foundation

class BankDto: Codable {
    var fsOrtEmpNo, fsOrtDtlDtm, lsOrtEmpNo, lsOrtDtlDtm: String?
    var instId, instClCD, instCD, instNm: String?
    var epsSeq: Int?
    var useYn, imgNm, imgURL: String?

    init(fsOrtEmpNo: String?, fsOrtDtlDtm: String?, lsOrtEmpNo: String?, lsOrtDtlDtm: String?, instId: String, instClCD: String, instCD: String, instNm: String, epsSeq: Int, useYn: String?, imgNm: String?, imgURL: String?) {
        self.fsOrtEmpNo = fsOrtEmpNo
        self.fsOrtDtlDtm = fsOrtDtlDtm
        self.lsOrtEmpNo = lsOrtEmpNo
        self.lsOrtDtlDtm = lsOrtDtlDtm
        self.instId = instId
        self.instClCD = instClCD
        self.instCD = instCD
        self.instNm = instNm
        self.epsSeq = epsSeq
        self.useYn = useYn
        self.imgNm = imgNm
        self.imgURL = imgURL
    }
}
