//
//  MbrInfo.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/17.
//

import Foundation

struct MbrInfo : Codable {
    
    init(uuid : String = "" , hpNo : String = "", mbrNm : String = "",monySertNo : String = "",instId : String = "",acntNo : String = "") {
        
        self.uuid = uuid
        self.hpNo = hpNo
        self.mbrNm = mbrNm
        self.acntNo = acntNo
        self.instId = instId
        self.monySertNo = monySertNo

    }
    
        var uuid: String?
        var hpNo: String?
        var mbrNm: String?
        var monySertNo: String?
        var instId: String?
        var acntNo: String?
    
}
