//
//  ResMnUseDto.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/30.
//

import Foundation
import SwiftUI

struct ResMnUseDto : Codable{

        var trxSno: String?
        var trxDt: String?
        var trxTm: String?
        var trxCl: String?
        var trxAmt: Int?
        var instNm: String?
        var acntNo: String?
        var mchtNm: String?
        var prodNm: String?
        var prodAmt: Int?
        var prodQty: Int?
    
    init(trxSno: String? = nil, trxDt: String? = nil, trxTm: String? = nil, trxCl: String? = nil, trxAmt: Int? = nil, instNm: String? = nil, acntNo: String? = nil, mchtNm: String? = nil, prodNm: String? = nil, prodAmt: Int? = nil, prodQty: Int? = nil) {
        self.trxSno = trxSno
        self.trxDt = trxDt
        self.trxTm = trxTm
        self.trxCl = trxCl
        self.trxAmt = trxAmt
        self.instNm = instNm
        self.acntNo = acntNo
        self.mchtNm = mchtNm
        self.prodNm = prodNm
        self.prodAmt = prodAmt
        self.prodQty = prodQty
    }
    
}
