//
//  asd.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/10.
//

import UIKit

class asd: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
