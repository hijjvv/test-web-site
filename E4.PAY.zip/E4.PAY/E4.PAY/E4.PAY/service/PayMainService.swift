//
//  PayMainService.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/19.
//

import Foundation
import Alamofire

class PayMainService {
    
    
    func
    getUserInfo(completion: @escaping (Result<Any, APIError>) -> Void ){
        
        let mbrNo = UserDefaults.standard.string(forKey: "mbrNo")! as String
        var data = ["mbrNo" : mbrNo , "monyInfoInqYn" : "y" , "acntInfoInqYn" : "y", "cardInfoInqYn" : "n"]
        let url = "http://192.168.10.150:48080/member/getInfo"
        let header: HTTPHeaders = [
                "Content-Type": "application/json;charset=UTF-8"
            ]

        NetworkManager.shared.request(url: url, method: .get, parameters: data , encoding: URLEncoding.default,headers : header){
            result in
            switch result {
            case .success(let value):
                completion(.success(value))
            case .failure(let error):
                completion(.failure(error))
            }
        }
            
        
    }
    func
    getCardInfo(completion: @escaping (Result<Any, APIError>) -> Void ){
        

        let url = "https://5da14cc4-ccee-4241-882a-0542ed1e111f.mock.pstmn.io/card/cardmock"
        let header: HTTPHeaders = [
                "Content-Type": "application/json;charset=UTF-8"
            ]

        NetworkManager.shared.request(url: url, method: .get, encoding: JSONEncoding.default ,headers : header){
            result in
            switch result {
            case .success(let value):
                completion(.success(value))
            case .failure(let error):
                completion(.failure(error))
            }
        }
            
        
    }
}

