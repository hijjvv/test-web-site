//
//  DataUtil.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/19.
//

import Foundation

class NumberUtil {
    static let shared = NumberUtil()

    private let formatter: NumberFormatter

    private init() {
        formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 0
    }

    func formatAmountWithoutDecimal(amount: Int) -> String {
        if let formattedAmount = formatter.string(from: NSNumber(value: amount)) {
            return formattedAmount
        } else {
            return "\(amount)"
        }
    }
}
