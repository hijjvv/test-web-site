//
//  PayMainPresenter.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/19.
//

import Foundation

protocol PayMainProtocol: AnyObject {
    func setDataPayMain(data : ResMbrInfo)
    
    func setCardDataPayMain(data : ResCardInfo)

    func displayError(message: String) 

}

// Presenter: View와 Model 간의 중간자 역할을 하는 부분
class PayMainPresenter {
    
    var payMainService: PayMainService


    
    weak var view: PayMainProtocol?
    
    // Model
    var resMbrInfo : ResMbrInfo?
    

    init(payMainService: PayMainService){
        self.payMainService = payMainService
    }

    
  
    func getMbrInfo() {
        payMainService.getUserInfo{ [weak self] result in
            switch result {
            case .success(let data):
 
                do {
                    let rdata = try JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)
                    let cfData = try JSONDecoder().decode(ResMbrInfo.self, from: rdata)
          

                self?.view?.setDataPayMain(data: cfData)
                } catch{
                    
                }
            case .failure(_):
//                self?.view?.displayError(message: "Error fetching user: \(error)")
                return
            }
        }
    }
    
    func getCardInfo() {
        payMainService.getCardInfo{ [weak self] result in
            switch result {
            case .success(let data):
 
                do {
                    let rdata = try JSONSerialization.data(withJSONObject: data, options: .prettyPrinted)
                    let cfData = try JSONDecoder().decode(ResCardInfo.self, from: rdata)
          

                    self?.view?.setCardDataPayMain(data: cfData)
                } catch{
                    print(error)
                }
            case .failure(_):
//                self?.view?.displayError(message: "Error fetching user: \(error)")
                return
            }
        }
    }
    
}
