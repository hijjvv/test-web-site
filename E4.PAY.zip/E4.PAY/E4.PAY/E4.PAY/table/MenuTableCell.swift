//
//  menuTableCell.swift
//  E4.PAY
//
//  Created by e4 on 2024/01/11.
//

import UIKit

class MenuTableCell: UITableViewCell {

    @IBOutlet weak var menuNm: UILabel!

}
