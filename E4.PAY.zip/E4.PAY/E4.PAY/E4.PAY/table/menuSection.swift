//
//  sectionc.swift
//  storyboard
//
//  Created by e4 on 2023/12/05.
//

import UIKit

protocol HeaderViewDelegate: AnyObject {
    func didTouchSection(_ sectionIndex: Int)
    
}

class menuSection: UITableViewHeaderFooterView {

    
    @IBOutlet weak var labelt: UILabel!
    let tapGestureRecognizer = UITapGestureRecognizer()
    var sectionIndex = 0
    var delegate: HeaderViewDelegate?
     
    var isopened = true
     
     
     //@IBOutlet weak var testt: UILabel!
     

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        contentView.addGestureRecognizer(tapGestureRecognizer)
        tapGestureRecognizer.addTarget(self, action: #selector(didSelectSection))
    }
    
    @objc func didSelectSection() {
        delegate?.didTouchSection(self.sectionIndex)
        isopened.toggle()
    }
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
