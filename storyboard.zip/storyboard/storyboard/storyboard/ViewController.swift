//
//  ViewController.swift
//  storyboard
//
//  Created by e4 on 2023/11/28.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    @IBOutlet weak var usrId: UITextField!
    @IBOutlet weak var usrPw: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // MARK: UIWindow의 rootViewController를 변경하여 화면전환
        func changeRootViewController(_ viewControllerToPresent: UIViewController) {
            if let window = UIApplication.shared.windows.first {
                window.rootViewController = viewControllerToPresent
                UIView.transition(with: window, duration: 0.5, options: .transitionCrossDissolve, animations: nil)
            } else {
                viewControllerToPresent.modalPresentationStyle = .overFullScreen
                self.present(viewControllerToPresent, animated: true, completion: nil)
            }
        }
    
    
    @IBAction func changeWindowButtonTocuhUpInside(_ sender: Any) {
          let newStoryboard = UIStoryboard(name: "MainPageNavi", bundle: nil)
          let newViewController = newStoryboard.instantiateViewController(identifier: "MainPageNavi")
          self.changeRootViewController(newViewController)
      }
    
    
    @IBAction func funcLogin(_ sender: Any) {
        tryLogin()
    }
    
    
    
    func  tryLogin() {
        
//        let data = ["usrId":usrId.text,
//                    "pwd"  :usrPw.text
//        ]
        
                let data = ["usrId":"jeaho.yoon",
                            "pwd"  :"!c12289760"
                ]
        
        let data2 = data as? [String: String]
        
        print("data 체크 : " , data)
        

        let url = "https://ekep.e4net.net/api/login.dc"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 10
        // POST 로 보낼 정보
        
        AF.request(url,
                   method : .post,
                   parameters : data2,
                   encoding : URLEncoding.default
        )
        .validate(statusCode: 0..<400)
        .responseJSON   {
            response in
            switch response.result {
                
            case .success(let value ):
                
                
                let data = value as? [String : Any]
                print("POST 성공" , data?["data"])
                do {
                    
                    let uInfo = data?["data"]
                    let data2 = uInfo as? [String : Any]
                    let data3 = data2?["ekepUserEntity"]
                    let rdata = try JSONSerialization.data(withJSONObject: data3!, options: .prettyPrinted)
                    let usrInfo = try JSONDecoder().decode(UsrInfo2.self, from:rdata)
                    UserDefaults.standard.setValue(data3 , forKey: "usrInfo")
                    
                    
                    let newStoryboard = UIStoryboard(name: "MainPage", bundle: nil)
                    let newViewController = newStoryboard.instantiateViewController(identifier: "MainPage")
                    
             
                    self.changeRootViewController(newViewController)

                    
                } catch {
                    print("token 받기" , error )
                }
                
                // print("token받기" , userInfo)
            case .failure(let error):
                print("error : \(error.errorDescription!)")
                print("error :", error)
            }
        }
        
        

        
    }
    
    
    

}

