//
//  TableHeader.swift
//  storyboard
//
//  Created by e4 on 2023/12/01.
//

import Foundation
import UIKit

protocol HeaderViewDelegate: AnyObject {
    func didTouchSection(_ sectionIndex: Int)
    
}

class TableHeader: UITableViewHeaderFooterView {
   let tapGestureRecognizer = UITapGestureRecognizer()
   var sectionIndex = 0
   var delegate: HeaderViewDelegate?
    
   var isopened = true
    
    static let headerViewID = "header"
    
    //@IBOutlet weak var testt: UILabel!
    
    public var testt: UILabel = {
        var topInset: CGFloat = 5.0
        var bottomInset: CGFloat = 5.0
        var leftInset: CGFloat = 8.0
        var rightInset: CGFloat = 8.0


        
         let label = UILabel()
         label.translatesAutoresizingMaskIntoConstraints = false
         label.adjustsFontForContentSizeCategory = true
         label.font = .preferredFont(forTextStyle: .body)
        label.textColor = .white
   
         return label
     }()
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        setupHeaderView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    
    private var verticalStackView: UIStackView = {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.backgroundColor = .blue
        return stackView
    }()
    
    private var verticalStackView2: UITableViewCell = {
        let stackView = UITableViewCell()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.backgroundColor = .blue
        return stackView
    }()
    
    private func setupHeaderView() {
        verticalStackView2.addSubview(testt)
        verticalStackView.addArrangedSubview(verticalStackView2)
        contentView.addSubview(verticalStackView)
        contentView.backgroundColor = UIColor(red: 33/255.0, green: 33/255.0, blue: 33/255.0, alpha: 1)
    }
    


   override func draw(_ rect: CGRect) {
       super.draw(rect)
       contentView.addGestureRecognizer(tapGestureRecognizer)
       tapGestureRecognizer.addTarget(self, action: #selector(didSelectSection))
   }
   
   @objc func didSelectSection() {
       delegate?.didTouchSection(self.sectionIndex)
       isopened.toggle()
   }
    

    
}
