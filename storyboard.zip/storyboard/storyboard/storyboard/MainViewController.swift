//
//  MainViewController.swift
//  storyboard
//
//  Created by e4 on 2023/11/28.
//

import UIKit
import Alamofire


class MainViewController:UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    // ekep-dev2.e4net.net/api/additionalInfo.dc    --point api
    
    @IBOutlet weak var myInfoView: UIView!
    @IBOutlet weak var myName: UILabel!
    @IBOutlet weak var myDepName: UILabel!
    
    @IBOutlet weak var pullPoint: UILabel!
    
    @IBOutlet weak var pullLeave: UILabel!
    
    @IBOutlet weak var myEmail: UILabel!
    
    var boardService = BoardService()
    
    @IBOutlet weak var infoImg: UIImageView!
    
    @IBOutlet weak var point: UILabel!
    
    @IBOutlet weak var leave: UILabel!
    
    @IBOutlet weak var leaveInfo: UILabel!
    
    @IBOutlet weak var pointInfo: UILabel!
    
    @IBOutlet weak var tvList: UITableView!
    
    var myPoint : MyPoint!
    var myLeave : MyLeave!
    
  
    var boardArray : [BoardDto] = []
   
    override func viewDidLoad()  {
        super.viewDidLoad()
        setMyInfo()
        viewShadow()
        getLeavePoint()
     
        //tvList.reloadData()
        
        // Do any additional setup after loading the view.
  
        print("boardArraay : ", boardArray )
    
    }
    
    func setMyInfo(){
        
        let data : [String:Any] = UserDefaults.standard.object(forKey: "usrInfo")! as? [String : Any] ??
        ["asd":"asd"]
        let d1 : String = data["fileHash"] as! String
        let d2 : String = data["emailId"] as! String
        let d3 : String = data["deptNm"] as! String
        let d4 : String = data["usrNm"] as! String
        
        DispatchQueue.main.async{
            let url = URL(string: "https://ipfs.e4net.net/ipfs/" + d1 )!
            if let data = (try? Data(contentsOf: url)){
                self.infoImg.image = UIImage(data: data)
            }
        }
        self.myEmail.text   = d2
        self.myDepName.text = d3
        self.myName.text    = d4
        
    }
    
    func setupChart() {
        let height = point.frame.size.height
        let height2 = leave.frame.size.height
        let toLeave = Int(pullLeave.frame.size.width) * (Int(myLeave.leaveRate))!/100
        
        let payP  = Int(myPoint.yearPayAmt)! - Int(myPoint.usePosblAmt)!
        
        
        let toPoint = Double(pullLeave.frame.size.width) * (Double(payP)/Double(myPoint.yearPayAmt)!)
        
        
        self.point.frame.size = CGSize(width: Double(toPoint), height: height)
        self.leave.frame.size = CGSize(width: Double(toLeave), height: height2)
        
        self.leaveInfo.text = myLeave.leaveDd + "/" + myLeave.useLeaveDd
        self.pointInfo.text = myPoint.yearPayAmt + "/" + myPoint.usePosblAmt
        
        
    }
    
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.getData()
        print("hi")
        print("boardArraay : ", boardArray )
    }
    


    //MARK: -TABLE VIEW DATASOURCE
    //row의 갯수
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        //단일이면 return 안 써도 된다.
        //self.sampleData.count
        return boardArray.count
    }
    
    //row의 형태
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tvList.dequeueReusableCell(withIdentifier: "testCell", for : indexPath)as!
        TableCellT
        
        cell.lbTitle.text = boardArray[indexPath.row].subject
        cell.writer.text = boardArray[indexPath.row].usrNm
        cell.writeDay.text = boardArray[indexPath.row].regDt
        cell.ctgr1.text = boardArray[indexPath.row].categoryNm
        
        var brdNo =  boardArray[indexPath.row].brdNo
        
        switch brdNo {
        case "1" :
            cell.tableName.text = "공지사항 >"
        case "3" :
            cell.tableName.text = "이야기방 >"
        case "4" :
            cell.tableName.text = "자료실 >"
        case "11" :
            cell.tableName.text = "IT서비스포럼 >"
        case "12" :
            cell.tableName.text = "언어서비스포럼 >"

        default:
            cell.tableName.text = "공지사항 >"
        }
        
        
        return cell
        
    }
    
    func viewShadow() {

        myInfoView.layer.shadowColor = UIColor.black.cgColor // 색깔
        myInfoView.layer.masksToBounds = false  // 내부에 속한 요소들이 UIView 밖을 벗어날 때, 잘라낼 것인지. 그림자는 밖에 그려지는 것이므로 false 로 설정
        myInfoView.layer.shadowOffset = CGSize(width: 0, height: 4) // 위치조정
        myInfoView.layer.shadowRadius = 5 // 반경
        myInfoView.layer.shadowOpacity = 0.3 // alpha값
        
    }
    
    
    
    func getData(){
        
        boardService.getBoardList{
            result in
           switch result {
           case.success(let data):
               
               
               self.boardArray = data as! [BoardDto]
               
               print(self.boardArray)
               self.tvList.reloadData()
           case.networkFail:
               print("fail")
           case .requestErr(_):
              return
           case .pathErr:
               return
           case .serverErr:
               return
           }
        }
    }
    
    
    func  getLeavePoint() {
        
//        let data = ["usrId":usrId.text,
//                    "pwd"  :usrPw.text
//        ]
        
                let data = ["usrId":"jeaho.yoon",
                            "pwd"  :"!c12289760"
                ]
        
        let data2 = data as? [String: String]
        
        print("data 체크 : " , data)
        

        let url = "https://ekep.e4net.net/api/additionalInfo.dc"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 10
        // POST 로 보낼 정보
        
        AF.request(url,
                   method : .post,
                   encoding : URLEncoding.default
        )
        .validate(statusCode: 0..<400)
        .responseJSON   {
            response in
            switch response.result {
                
            case .success(let value ):
                
                
                let data = value as? [String : Any]
                print("POST 성공" , data?["data"])
                do {
                    
                    let uInfo = data?["data"]
                    let data2 = uInfo as? [String : Any]
                    let data3 = data2?["leaveStatus"]
                    let data4 = data2?["pointStatus"]
                    
                    let convertedData = self.convertValuesToString(data3)
                    let convertedData2 = self.convertValuesToString(data4)
                    
                    
                    let rdata = try JSONSerialization.data(withJSONObject: convertedData!, options: .prettyPrinted)
                    self.myLeave = try JSONDecoder().decode(MyLeave.self, from:rdata)

                    
                    let rdata2 = try JSONSerialization.data(withJSONObject: convertedData2!, options: .prettyPrinted)
                    self.myPoint = try JSONDecoder().decode(MyPoint.self, from:rdata2)
                    self.setupChart()
                    

                } catch {
                    print(error )
                }
                
                // print("token받기" , userInfo)
            case .failure(let error):
                print("error : \(error.errorDescription!)")
                print("error :", error)
            }
        }
        
        

        
    }
    
    
    func convertValuesToString(_ value: Any?) -> Any? {
        switch value {
        case let intValue as Int:
            return String(intValue)
        case let doubleValue as Double:
            return String(doubleValue)
        case let nestedDictionary as [String: Any?]:
            return nestedDictionary.mapValues { convertValuesToString($0) }
        default:
            return value
        }
    }
    
    
    
    

}

