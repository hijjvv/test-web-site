//
//  asdasdTableViewCell.swift
//  storyboard
//
//  Created by e4 on 2023/12/04.
//

import UIKit

class asdasdTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
