//
//  NetworkResult.swift
//  storyboard
//
//  Created by e4 on 2023/11/30.
//

import Foundation

enum NetworkResult<T>{
    case success(T)
    case requestErr(T)
    case pathErr
    case serverErr
    case networkFail
}
