//
//  usrDto.swift
//  storyboard
//
//  Created by e4 on 2023/12/05.
//

import Foundation


class UsrInfo : Codable{
    
    var deptNm   : String = ""
    var hanNm    : String = ""
    var engNm    : String = ""
    var mobile   : String = ""
    var fileHash : String = ""
    var mbrGd    : String = ""
    var birthYmd : String = ""
    var email    : String = ""
    var jncmpYmd : String = ""
    
    
}

class UsrInfo2 : Codable{
    
    var deptNm   : String = ""
    var hanNm    : String = ""
    var fileHash : String = ""
    
    
}
