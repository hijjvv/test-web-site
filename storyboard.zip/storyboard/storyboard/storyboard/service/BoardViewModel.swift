//
//  BoardViewModel.swift
//  storyboard
//
//  Created by e4 on 2023/11/29.
//

//
//  BoardViewModel.swift
//  sample
//
//  Created by e4 on 2023/11/29.
//
//
//  UserVM.swift
//  jeahotest1
//
//  Created by e4 on 2023/11/27.
//

import Foundation
import Alamofire
import UIKit

/* @brief : 로그인 viewmodel
 */

class BoardService {
    // 싱글톤객체로 사용할 수도 있음
    //static let shared = BoardViewModel()
    
    var boardDto : [BoardDto] = []
    
    @Published var loginSuccess : Bool = false
    @Published var loginFailAlert : Bool = false
    
    /* @brief : 로그인 api
     */
    func  getBoardList(completion:@escaping(NetworkResult<Any>) -> Void) {
        
        let data = ["pageRows":10
        ]
        
        
        let cookieProperties = [
            HTTPCookiePropertyKey.domain : "ekep.e4net.net",
            HTTPCookiePropertyKey.path : "/",
            HTTPCookiePropertyKey.name: "jwt",
            HTTPCookiePropertyKey.value: "eyJhbGciOiJFUzI1NiJ9.eyJ1c3JObyI6IjEwMDAxMzU5IiwidXNySWQiOiJqZWFoby55b29uIiwidXNyTm0iOiLsnKTsnqztmLgiLCJvcmdObyI6IjEwMDAwIiwib3JnTm0iOiIo7KO8KeydtO2PrOuEtyIsImRlcHRJZCI6IjEwMDAwMDA0IiwiZGVwdE5tIjoiSVTshJzruYTsiqTsgqzsl4Xrs7jrtoAiLCJkdXR5Q2QiOiI5MSIsImVtYWlsSWQiOiJqZWFoby55b29uQGU0bmV0Lm5ldCIsIm1ick5vIjoiMjAyMjEwMDAxIiwic3lzQWRtaW4iOiJmYWxzZSIsInN1YiI6ImplYWhvLnlvb24iLCJleHAiOjE3MDEzMTgwMzQsImlhdCI6MTcwMTMwMzE4NCwibG9naW5BdCI6MTcwMTMwMDIzMzU4OSwicmVmSW50ZXJ2YWwiOiI5MDAwMDAiLCJzZXNzaW9uSWQiOiIyYTgzNzU1OTJjZmRlM2MzZmYyMzQ5OTMzN2FkZDE1ZGMyZDY4N2ZjIn0.c_zBhksC-8Mg9ZyNojsFfgSAF35IqWwR3pvIJDr6Qtn3sFkgjP63Wbsmb6AOjJkNW8WGzGbDmowJpNKPUVEg3g"
            
        ]
        if let cookie = HTTPCookie(properties: cookieProperties){
            
            AF.session.configuration.httpCookieStorage?.setCookie(cookie)
            
        }
        
        
        let url = "https://ekep.e4net.net/api/boardAllContentList.dc"
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 10
        // POST 로 보낼 정보
        
        AF.request(url,
                   method : .post,
                   parameters : data,
                   encoding : URLEncoding.default
        )
        .validate(statusCode: 0..<400)
        .responseJSON   {
            response in
            switch response.result {
                
            case .success(let value ):
                
                
                let data = value as? [String : Any]
                print("POST 성공" , data?["data"])
                let boardlist = data?["data"]
                let data2 = boardlist as? [String : Any]
                
                let data3 = data2?["list"]
                
                
                do {
                    let rdata = try JSONSerialization.data(withJSONObject: data3, options: .prettyPrinted)
                    
                    
                    
                    let boardInfo = try JSONDecoder().decode([BoardDto].self, from: rdata)
                    //예){"email" : "hi", "result" : "성공"}
                    
                    self.boardDto = boardInfo
                   // print("token 받기,대입" , self.boardDto )
    
                    guard let statusCode = response.response?.statusCode
                    else {return}
                    guard let data = response.data else {return}
                    
                    
                    
                    
                    let networkResult = self.judgeStatus(by: statusCode, boardInfo as! [Any] ,[BoardDto].self)
                    completion(networkResult)
                    
                } catch {
                    print("token 받기" , error )
                }
                
                // print("token받기" , userInfo)
            case .failure(let error):
                print("error : \(error.errorDescription!)")
                print("error :", error)
                self.loginFailAlert = true
            }
        }
        
        

        
    }
    
    
    
    
    
    
    func judgeStatus<T: Codable>(by statusCode: Int, _ data: [Any], _ type: T.Type) -> NetworkResult<Any> {
        let decoder = JSONDecoder()
         let decodedData = data

        print(decodedData)
        switch statusCode {
        case 0 :
            return .success(decodedData as Any)
        case 200:
            return .success(decodedData as Any)
        case 201..<300:
            return .success(decodedData as Any)
        case 400..<500:
            return .requestErr(decodedData)
        case 500:
            return .serverErr
        default:
            return .networkFail
        }
    }

}

/* @brief : 로그인 model
 */
struct LoginModel : Codable{
    
    
    var  usrId  : String = ""
    var  pwd  : String = ""
    
    
    init(usrId: String, pwd: String) {
        self.usrId = usrId
        self.pwd = pwd
    }
    
}



/* @brief : token dto
 */
struct TokenDto : Codable{
    
    var  accessToken  : String = ""
    var  membCls      : String = ""
    var  membId       : String = ""
    var  membSn       : Int    = 0
    
}

struct BoardDto : Codable{
    
    var brdNo        : String = ""
    var postNo       : String = ""
    var categoryNm   : String = ""
    var categoryNm2  : String = ""
    var regDt        : String = ""
    var usrNm        : String = ""
    var subject      : String = ""
    
    
}
