////
////  Sidebar.swift
////  storyboard
////
////  Created by e4 on 2023/12/01.
////
//
//import Foundation
//import UIKit
//
//class SideMenuViewController: UIViewController,HeaderViewDelegate , UITableViewDataSource, UITableViewDelegate {
//   
//    @IBOutlet weak var usrList: UITableView!
//
//    
//    var isOpen = [true,true,false,false]
//    let numberList : [String] = ["1","2","3","4"]
//    let depNm : [String] = ["대표이사","기술연구소","IT사업본부","경영지원실"]
//    
//    let dataList  = ["사과", "바나나", "딸기"]
//    
//    
//    
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.usrList.reloadData()
//        //self.usrList.register( CustomHeaderView.self, forHeaderFooterViewReuseIdentifier: "CustomHeaderView")
//        
//        self.usrList.register(TableHeader.self, forHeaderFooterViewReuseIdentifier: TableHeader.headerViewID)
//        
//    }
//    
//
//    
//    
////    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
////         // Header 영역 크기 = 140(separator 상단) + 12(separator 하단)
////
////         return 1
////     }
//    
//    func didTouchSection(_ sectionIndex: Int) {
//        self.isOpen[sectionIndex].toggle()
//        self.usrList.reloadData()
//
//    }
//    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return depNm.count
//    }
//    
//    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if isOpen[section] == true {
//            return dataList.count
//        } else {
//
//            return 0
//        }
//        return dataList[section].count
//    }
//    
//
//    
//      func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//          guard let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: TableHeader.headerViewID) as? TableHeader else { return UITableViewHeaderFooterView() }
//
//            headerView.sectionIndex = section // 여기서 담아 줍니다.
//          
//          let target = depNm[section]
//          headerView.testt.text = target
//          headerView.delegate = self
//          headerView.isopened = isOpen[section]
//            return headerView
//        }
//    
//
//
//    
//
//    
//    
//    
//    //row의 형태
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//
//        let cell = usrList.dequeueReusableCell(withIdentifier: "ttcell", for : indexPath)as!
//        TableCellT
//        
//        let target = dataList[indexPath.row]
//        cell.test1.text = target
//        
//        return cell
//        
//    }
//    
//    
//    
//    
//    
//
//}
