//
//  Sidebar.swift
//  storyboard
//
//  Created by e4 on 2023/12/01.
//

import Foundation
import UIKit
import Alamofire

class SideMenuViewController: UIViewController,HeaderViewDelegate , UITableViewDataSource, UITableViewDelegate, HeaderViewDelegate2 {
   
    @IBOutlet weak var usrList: UITableView!

    
    var isOpen = [true,true,true,true]
    let numberList : [String] = ["1","2","3","4"]
    let depNm : [String] = ["대표이사","기술연구소","IT사업본부","경영전략실"]
    
    let dataList  = ["사과", "바나나", "딸기"]
    
    var usrDataList : [[UsrInfo]] = [[]]
    
    var usrDataList1 : [UsrInfo] = []
    var usrDataList2 : [UsrInfo] = []
    var usrDataList3 : [UsrInfo] = []
    var usrDataList4 : [UsrInfo] = []
    
    var prepareData  : UsrInfo!
    

    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getUsrList()
    
        //self.usrList.register( CustomHeaderView.self, forHeaderFooterViewReuseIdentifier: "CustomHeaderView")
        
        let headerNib = UINib(nibName: "Section", bundle: nil)
        usrList.register(headerNib, forHeaderFooterViewReuseIdentifier: "customHeader")
        
        usrList.sectionHeaderTopPadding = 0
        
    }
    

    
    
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//         // Header 영역 크기 = 140(separator 상단) + 12(separator 하단)
//
//         return 1
//     }
    
    func didTouchSection(_ sectionIndex: Int) {
        self.isOpen[sectionIndex].toggle()
        self.usrList.reloadSections(IndexSet(arrayLiteral: sectionIndex,sectionIndex), with: UITableView.RowAnimation.automatic)

    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return depNm.count
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isOpen[section] == true{
            switch section {
            case 0 :
                return usrDataList1.count
            case 1 :
                return usrDataList2.count
            case 2 :
                return usrDataList3.count
            case 3 :
                return usrDataList4.count
            default:
                return 0
              
            }
        } else{
            return 0
        }
        
    
    }
    

    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let headerView = tableView.dequeueReusableHeaderFooterView(withIdentifier: "customHeader") as? sectionc else { return UITableViewHeaderFooterView() }

          headerView.sectionIndex = section // 여기서 담아 줍니다.
        
        let target = depNm[section]
        headerView.labelt.text = target
        headerView.delegate = self
        headerView.isopened = isOpen[section]
          return headerView
      }
  



  

  
  
  
  //row의 형태
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

      let cell = usrList.dequeueReusableCell(withIdentifier: "ttcell", for : indexPath)as!
      TableCellT
      
      
      let target = usrDataList[indexPath.section][indexPath.row].hanNm
      let target2 = usrDataList[indexPath.section][indexPath.row].engNm
      let target3 = usrDataList[indexPath.section][indexPath.row].mobile
      let target4 = usrDataList[indexPath.section][indexPath.row].fileHash
      DispatchQueue.global().async{

          let url: URL = URL(string: "https://ipfs.e4net.net/ipfs/" + self.usrDataList[indexPath.section][indexPath.row].fileHash)!
          if let data = (try? Data(contentsOf: url)){
              let image = UIImage(data: data)
              
              let targetSize = CGSize(width: 35, height: 45)
              
              let resizedImage = image?.resized(to:targetSize)
              
              DispatchQueue.main.async{
                  
                 cell.test4.image = resizedImage
                  
              }
          }
      }
      
      cell.test1.text = target
      cell.test2.text = target2
      
      cell.test3.text = target3

      
      
      return cell
      
      
      
      
  }

// 팝업띄우기의 다른버젼, perpormsegue로 띄울 수 있다.
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//
//        self.prepareData = usrDataList[indexPath.section][indexPath.row]
//        let storyBoard = UIStoryboard.init(name: "MainPage", bundle: nil)
//        let popupVC = storyBoard.instantiateViewController(withIdentifier: "PopUpViewCrt")
//        popupVC.modalPresentationStyle = .overCurrentContext
//        present(popupVC, animated: false, completion: nil)
//
//
//
//    }
    

//    //Table View Cell
//    override func prepareForReuse() {
//        super.prepareForReuse()
//
//        print("_hyeon prepareForReuse: ", ServiceViewControl().tagSectionRowTable)
//        btnNotice.isSelected = false
//    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "PopUpViewCrt"{
                if let destination = segue.destination as?
                    PopUpViewCrt {
                    if let selectdeIndex =
                        self.usrList.indexPathForSelectedRow?.row {
                     
                     
                        
                        self.prepareData = usrDataList[   usrList.indexPathForSelectedRow!.section][usrList.indexPathForSelectedRow!
                            .row]
                        
                        destination.prepareUsrInfo = self.prepareData
                    }
                }
            }
        }
    
    
    
  
  
  func  getUsrList() {
      
//        let data = ["usrId":usrId.text,
//                    "pwd"  :usrPw.text
//        ]
      
              let data = ["pageRows":"30"
              ]
      
      let data2 = data as? [String: String]
      
      print("data 체크 : " , data)
      

      let url = "https://ekep.e4net.net/api/employeeList.dc"
      var request = URLRequest(url: URL(string: url)!)
      request.httpMethod = "POST"
      request.setValue("application/json", forHTTPHeaderField: "Content-Type")
      request.timeoutInterval = 10
      // POST 로 보낼 정보
      
      AF.request(url,
                 method : .post,
                 parameters : data2,
                 encoding : URLEncoding.default
      )
      .validate(statusCode: 0..<400)
      .responseJSON   {
          response in
          switch response.result {
              
          case .success(let value ):
              
              
              let data = value as? [String : Any]
              print("POST 성공" , data?["data"])
              do {
                  
                  
                  let data = value as? [String : Any]
                  print("POST 성공" , data?["data"])
                  let boardlist = data?["data"]
                  let data2 = boardlist as? [String : Any]
                  
                  let data3 = data2?["employeeList"]

                  let rdata = try JSONSerialization.data(withJSONObject: data3, options: .prettyPrinted)
                  
                  
                  
                  let usrInfo = try JSONDecoder().decode([UsrInfo].self, from: rdata)
                  //예){"email" : "hi", "result" : "성공"}

                  for i in usrInfo {
                      
                      switch i.deptNm {
                      case  "대표이사" :
                          self.usrDataList1.append(i)
                      case  "기술연구소" :
                          self.usrDataList2.append(i)
                      case  "IT서비스사업본부" :
                          self.usrDataList3.append(i)
                      case  "경영전략실" :
                          self.usrDataList4.append(i)
                      default:
                         continue
                      }
                    
                  }
                  self.usrDataList.insert(self.usrDataList1, at: 0)
                  self.usrDataList.insert(self.usrDataList2, at: 1)
                  self.usrDataList.insert(self.usrDataList3, at: 2)
                  self.usrDataList.insert(self.usrDataList4, at: 3)
                  
                  self.usrList.reloadData()
                  
              } catch {
                  print("" , error )
              }
              
              // print("token받기" , userInfo)
          case .failure(let error):
              print("error : \(error.errorDescription!)")
              print("error :", error)
          }
      }
      
      

      
  }
    
  
  
  

}

extension UIImage {
    func resized(to size : CGSize) -> UIImage?{
        UIGraphicsBeginImageContextWithOptions(size, false, 0.0)
        defer {UIGraphicsEndImageContext()}
        draw(in: CGRect(origin: .zero, size: size))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
}
