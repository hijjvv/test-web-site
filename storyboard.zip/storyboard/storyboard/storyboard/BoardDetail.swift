//
//  BoardDetail.swift
//  storyboard
//
//  Created by e4 on 2023/12/06.
//

import Foundation
import WebKit

class BoardDetailCtr: UIViewController {

    @IBOutlet var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        webView = WKWebView(frame: self.view.frame)
        self.view = webView
        
        let url = URL(string: "https://ekep-dev.e4net.net/board/boardView2.do")
        var request = URLRequest(url: url!)
        request.httpMethod = "POST"
        
        let body :[String:String] = [
                    "brdNo" : "1",
                    "postNo" : "1258"
                ]
        let jsonData = try? JSONSerialization.data(withJSONObject: body)
        
        request.httpBody = jsonData
        
        webView.allowsBackForwardNavigationGestures = true // 뒤로가기 제스처 허용
        
        webView.configuration.preferences.javaScriptEnabled = true
        
        webView.load(request)
    }


}
