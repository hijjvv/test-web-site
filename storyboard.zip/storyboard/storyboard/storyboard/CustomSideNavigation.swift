//
//  CustomSideNavigation.swift
//  storyboard
//
//  Created by e4 on 2023/12/01.
//

import UIKit
import SideMenu

class CustomSideMenuNavigation: SideMenuNavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.menuWidth = self.view.frame.width * 0.8

    }
    
}
