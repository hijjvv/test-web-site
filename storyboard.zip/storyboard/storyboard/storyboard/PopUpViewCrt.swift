//
//  PopUpViewCrt.swift
//  storyboard
//
//  Created by e4 on 2023/12/05.
//


import UIKit

class PopUpViewCrt:UIViewController{
    

    
    var prepareUsrInfo : UsrInfo!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var job: UILabel!
    
    @IBOutlet weak var email: UILabel!
    
    @IBOutlet weak var joinDay: UILabel!
    
    @IBOutlet weak var birthDay: UILabel!
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var popupView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.name.text = prepareUsrInfo.hanNm
        
        var url = URL(string: "https://ipfs.e4net.net/ipfs/" + prepareUsrInfo.fileHash)!
        if let data = (try? Data(contentsOf: url)){
            self.img.image = UIImage(data: data)
        }
        
        self.job.text = prepareUsrInfo.mbrGd
        self.email.text = prepareUsrInfo.email
        self.joinDay.text = prepareUsrInfo.jncmpYmd
        self.birthDay.text = prepareUsrInfo.birthYmd
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.didTappedOutside(_:)))
        let tapGestureRecognizer2 = UITapGestureRecognizer(target: self, action: #selector(self.didTappedOutside2(_:)))
        
        
      
        self.view.addGestureRecognizer(tapGestureRecognizer)
        self.popupView.addGestureRecognizer(tapGestureRecognizer2)
    }
    
    
    @objc
    private func didTappedOutside(_ sender: UITapGestureRecognizer) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc
    private func didTappedOutside2(_ sender: UITapGestureRecognizer) {
        return
    }
    
    
}

