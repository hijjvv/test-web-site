//
//  cell.swift
//  storyboard
//
//  Created by e4 on 2023/11/28.
//

//
//  SecondTableViewCell.swift
//  sample
//
//  Created by e4 on 2023/11/06.
//

import UIKit

class TableCellT : UITableViewCell{
    
    @IBOutlet weak var ivImage: UIImageView!
    
    @IBOutlet weak var lbTitle: UILabel!
    
    @IBOutlet weak var writer: UILabel!
    
    @IBOutlet weak var writeDay: UILabel!
    
    @IBOutlet weak var ctgr1: UILabel!
    
    @IBOutlet weak var tableName: UILabel!
    
    @IBOutlet weak var test1: UILabel!
    
    @IBOutlet weak var test2: UILabel!
    
    @IBOutlet weak var test3: UILabel!
    
    @IBOutlet weak var test4: UIImageView!
    
}
