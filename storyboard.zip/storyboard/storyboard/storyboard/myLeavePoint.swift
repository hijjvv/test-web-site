//
//  myLeavePoint.swift
//  storyboard
//
//  Created by e4 on 2023/12/12.
//

import Foundation

class MyLeave : Codable {
    


    var leaveDiff : String
    var leaveRate : String
    var useLeaveDd : String
    var nopayLeaveDd : String
    var officeLeaveDd : String
    var leaveDd : String

}

class MyPoint : Codable {
    


    var yearPayAmt : String
    var usePosblAmt : String

}
