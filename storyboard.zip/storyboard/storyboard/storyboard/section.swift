//
//  section.swift
//  storyboard
//
//  Created by e4 on 2023/12/05.
//

import UIKit

class section: UITableViewHeaderFooterView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
