//
//  myInfoView.swift
//  storyboard
//
//  Created by e4 on 2023/12/11.
//

import Foundation
import UIKit

class MyInfoView : UIViewController {
    
    @IBOutlet weak var myInfoName: UILabel?
    
}

