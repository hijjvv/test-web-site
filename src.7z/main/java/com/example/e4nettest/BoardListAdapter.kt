package com.example.e4nettest

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.e4nettest.databinding.DeptListBinding
import com.example.e4nettest.databinding.ListItemBinding

class BoardListAdapter (val context: Context, val boardList: ArrayList<BoardDto>) : BaseAdapter() {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

            /* LayoutInflater는 item을 Adapter에서 사용할 View로 부풀려주는(inflate) 역할을 한다. */
            val view: View = LayoutInflater.from(context).inflate(R.layout.list_item, null)
            val binding = ListItemBinding.inflate(LayoutInflater.from(parent!!.context), parent, false)

            binding.model = boardList[position]

            /* 위에서 생성된 view를 res-layout-main_lv_item.xml 파일의 각 View와 연결하는 과정이다. */
            val writer = view.findViewById<TextView>(R.id.textView1)
            val subject = view.findViewById<TextView>(R.id.textView2)


            val board = boardList[position]

            writer.text = board.usrNm
            subject.text = board.subject

            when(board.brdTblNm) {
                "CM_BOARD" -> binding.tbNm.text = "공지사항 >"
                "CM_BOARD" -> binding.tbNm.text = "공지사항 >"
                "CM_BOARD" -> binding.tbNm.text = "공지사항 >"
                else -> binding.tbNm.text = "공지사항 >"
            }




            return binding.root
        }

        override fun getItem(position: Int): Any {
            return boardList[position]
        }

        override fun getItemId(position: Int): Long {
            return 0
        }

        override fun getCount(): Int {
            return boardList.size
        }
    }
