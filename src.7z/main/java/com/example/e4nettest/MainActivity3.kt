package com.example.e4nettest

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import com.google.gson.JsonObject
import okhttp3.Cache
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.net.CookieManager
import java.util.Objects
import java.util.concurrent.TimeUnit

class MainActivity3 : AppCompatActivity() {


    val httpClient = OkHttpClient.Builder()
        .cookieJar(JavaNetCookieJar(CookieManager()))
        .readTimeout(30, TimeUnit.SECONDS)
        .build()



    val retrofit = RetrofitService.retrofit
    val loginApi = retrofit.create(ApiInterface::class.java)


    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLogin : Button = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            login()

        }

    }


    fun login(){
        loginApi.login("jeaho.yoon","!c12289760").enqueue(object: Callback<Map<String, Any>> {
            override fun onResponse(call: Call<Map<String, Any>> , response: Response<Map<String, Any>>){

                if(response.isSuccessful.not()){
                    return
                }



                response.body()?.let{
                    Log.d("OK",  it["data"].toString() )

                        if (it["ok"] as Boolean  == true ) {

                            val intent = Intent(baseContext, MainpageActivity::class.java)
                            startActivity(intent)

                        }

                } ?: run {
                    Log.d("NG", "body is null")
                }
            }

            override fun onFailure(call: Call<Map<String, Any>>, t: Throwable) {
                Log.e("ERROR", t.toString())
                Toast.makeText(applicationContext, t.toString(), Toast.LENGTH_LONG).show()
            }

        })
    }


}

