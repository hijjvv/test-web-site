package com.example.e4nettest

import android.util.SparseBooleanArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.e4nettest.databinding.DeptListBinding
import android.content.Context
import android.graphics.Color
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DividerItemDecoration

class UsrListAdapter(val context: Context, val itemList:  Map<String,ArrayList<UsrDto>>) : RecyclerView.Adapter<UsrListAdapter.BoardViewHolder>() {



        // item 리스트 array
        var listData = arrayListOf("대표이사","기술연구소","IT서비스사업본부","경영전략실")
        var boolData = arrayListOf(true,true,false,false)



        var listData2 : ArrayList<Any>  =  ArrayList<Any>()
        // item의 클릭 상태 저장 array
        var  selectedItems : SparseBooleanArray =  SparseBooleanArray()
        // 직전에 클릭됐던 item의 position
        var  prePosition : Int = -1;

    private lateinit var binding : DeptListBinding

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BoardViewHolder {
        val binding = DeptListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BoardViewHolder(binding)

    }

    override fun onBindViewHolder(holder: BoardViewHolder, position: Int) {
        holder.deptNm.text = listData[position]
        if (listData[position] == "대표이사"){
            holder.bind()
        }  else if (listData[position] == "기술연구소"){
            holder.bind2()
        }  else if (listData[position] == "IT서비스사업본부"){
            holder.bind3()
        }  else if (listData[position] == "경영전략실"){
            holder.bind4()
        }

    }

    override fun getItemCount(): Int {
        return listData.size
    }

    inner class BoardViewHolder(var binding: DeptListBinding) : RecyclerView.ViewHolder(binding.root) {
        val deptNm = itemView.findViewById<TextView>(R.id.deptNm)



        fun setting(){
            binding.constraintLayout2.setOnClickListener {

                if( binding.innerRecyclerList.isVisible == true){
                    binding.innerRecyclerList.isVisible = false
                } else{
                    binding.innerRecyclerList.isVisible = true
                }

            }
        }



        fun bind() {
            setting()
            binding.innerRecyclerList.adapter = UsrInnnerListAdater(context,itemList.get("대표이사")!!)
            binding.innerRecyclerList.addItemDecoration(DividerItemDecoration(context, 1))
            binding.innerRecyclerList.layoutManager = LinearLayoutManager(context)

        }

        fun bind2() {
            setting()
            binding.innerRecyclerList.adapter = UsrInnnerListAdater(context,itemList.get("기술연구소")!!)
            binding.innerRecyclerList.addItemDecoration(DividerItemDecoration(context, 1))
            binding.innerRecyclerList.layoutManager = LinearLayoutManager(context)

        }
        fun bind3() {
            setting()
            binding.innerRecyclerList.adapter = UsrInnnerListAdater(context,itemList.get("IT서비스사업본부")!!)
            binding.innerRecyclerList.addItemDecoration(DividerItemDecoration(context, 1))
            binding.innerRecyclerList.layoutManager = LinearLayoutManager(context)

        }
        fun bind4() {
            setting()
            binding.innerRecyclerList.adapter = UsrInnnerListAdater(context,itemList.get("경영전략실")!!)
            binding.innerRecyclerList.addItemDecoration(DividerItemDecoration(context, 1))
            binding.innerRecyclerList.layoutManager = LinearLayoutManager(context)

        }

    }



}


