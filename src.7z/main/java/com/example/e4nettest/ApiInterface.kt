package com.example.e4nettest

import android.provider.ContactsContract.Data
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.Objects

interface ApiInterface {
    @GET("login.dc")
    fun login(
        @Query("usrId") usrId: String,
        @Query("pwd") pwd: String
    ) : Call<Map<String, Any>>


    @POST("boardAllContentList.dc")
    fun getBoardList(
        @Query("pageRows") pageRows: String,
    ) : Call<Map<String,Any>>

    @POST("employeeList.dc")
    fun getUsrList(
        @Query("pageRows") pageRows: String,
    ) : Call<Map<String,Any>>


}