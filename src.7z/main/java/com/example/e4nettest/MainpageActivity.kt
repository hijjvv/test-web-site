package com.example.e4nettest

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.CookieManager
import java.util.concurrent.TimeUnit


class MainpageActivity : AppCompatActivity() {

    val gson : Gson = GsonBuilder()
        .setLenient()
        .create()

    val httpClient = OkHttpClient.Builder()
        .cookieJar(JavaNetCookieJar(CookieManager()))
        .readTimeout(30, TimeUnit.SECONDS)
        .build()


    val retrofit = RetrofitService.retrofit
    val ekepApi = retrofit.create(ApiInterface::class.java)

     var boardList : ArrayList<BoardDto>? = null
    var usrList : ArrayList<UsrDto>? = null

    lateinit var boardListView : ListView
    lateinit var outRecyclerList : RecyclerView
    lateinit var innerRecyclerList : RecyclerView
    lateinit var boardAdapter : BoardListAdapter
    lateinit var usrListAdapter : UsrListAdapter



    var a = UsrDto("hihihi")
    var a2 = UsrDto("hello")
    var a3 = UsrDto("android~")

    var a4 = UsrDto("123")
    var a5 = UsrDto("123")
    var a6 = UsrDto("123~")


    var itemList2 = ArrayList<UsrDto>()
    var itemList3 = ArrayList<UsrDto>()

    var abc =  let  {     itemList2.add(a)
        itemList2.add(a2)
        itemList2.add(a3)

        itemList3.add(a4)
        itemList3.add(a5)
        itemList3.add(a6)

    }

    var itemList : Map<String,ArrayList<UsrDto>> = mapOf("1" to itemList2 , "2" to itemList3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mainpage)
        getBoardList()


        boardListView  = findViewById(R.id.boardListView)


        val mypage_drawer = findViewById<DrawerLayout>(R.id.main_drawer_layout)
        val mypage_menu_btn = findViewById<Button>(R.id.button1)
        mypage_menu_btn.setOnClickListener {
            mypage_drawer.openDrawer(GravityCompat.END)
        }

         outRecyclerList = findViewById<RecyclerView>(R.id.out_recycler_list)
//        innerRecyclerList = findViewById<RecyclerView>(R.id.inner_recycler_list)
        outRecyclerList.addItemDecoration(DividerItemDecoration(this.baseContext, 1))
        getUsrList()


    }

    fun getBoardList(){
        ekepApi.getBoardList("15").enqueue(object: Callback<Map<String,Any>> {



            override fun onResponse(call: Call<Map<String,Any>>, response: Response<Map<String,Any>>){
                if(response.isSuccessful.not()){
                    return
                }
                response.body()?.let{
                    Log.d("OK",  it.toString() )

                if (response.isSuccessful()) {
                    val gson = Gson()
                    var data  =  it as Map<String,Any>
                    var list  =  it["data"] as Map<String,Any>
                    val jsonString = gson.toJson(list["list"])
                    val listType = object : TypeToken<ArrayList<BoardDto>>(){}.type
                    var data2 : ArrayList<BoardDto> = gson.fromJson(jsonString,listType)



                    boardList = data2 as ArrayList<BoardDto>
                    boardAdapter = BoardListAdapter(baseContext, boardList!!)
                    boardListView.adapter = boardAdapter


                }

                } ?: run {
                    Log.d("NG", "body is null")
                }
            }

            override fun onFailure(call: Call<Map<String,Any>>, t: Throwable) {
                Log.e("ERROR", call.toString())
                Log.e("ERROR", t.toString())
                Toast.makeText(applicationContext, t.toString(), Toast.LENGTH_LONG).show()
            }

        })
    }

    fun getUsrList(){
        ekepApi.getUsrList("30").enqueue(object: Callback<Map<String,Any>> {



            override fun onResponse(call: Call<Map<String,Any>>, response: Response<Map<String,Any>>){
                if(response.isSuccessful.not()){
                    return
                }
                response.body()?.let{
                    Log.d("OK",  it.toString() )

                    if (response.isSuccessful()) {
                        val gson = Gson()
                        var data  =  it as Map<String,Any>
                        var list  =  it["data"] as Map<String,Any>
                        val jsonString = gson.toJson(list["employeeList"])
                        val listType = object : TypeToken<ArrayList<UsrDto>>(){}.type
                        var data2 : ArrayList<UsrDto> = gson.fromJson(jsonString,listType)

                        usrList = data2 as ArrayList<UsrDto>

                        var abc : Map<String,ArrayList<UsrDto>> = usrList!!.groupBy { it.deptNm } as Map<String,ArrayList<UsrDto>>

                        usrListAdapter = UsrListAdapter(baseContext ,abc)
                        //usrListAdapter.notifyDataSetChanged()
                        outRecyclerList.adapter = usrListAdapter


                    }

                } ?: run {
                    Log.d("NG", "body is null")
                }
            }

            override fun onFailure(call: Call<Map<String,Any>>, t: Throwable) {
                Log.e("ERROR", call.toString())
                Log.e("ERROR", t.toString())
                Toast.makeText(applicationContext, t.toString(), Toast.LENGTH_LONG).show()
            }

        })
    }



}