package com.example.e4nettest

import com.google.gson.annotations.SerializedName

class BoardDto(usrNm: String) {
    @SerializedName("brdNo")
    var brdNo: String? = ""
    @SerializedName("ctgr1Cd")
    var ctgr1Cd: String? = ""
    @SerializedName("categoryNm")
    var categoryNm: String? = ""
    @SerializedName("categoryNm2")
    var categoryNm2: String? = ""
    @SerializedName("subject")
    var subject: String? = ""
    @SerializedName("usrNm")
    var usrNm: String? = ""
    @SerializedName("regDt")
    var regDt: String? = ""
    @SerializedName("brdTblNm")
    var brdTblNm: String? = ""

    init {
        this.usrNm = usrNm
    }

}