package com.example.e4nettest

import com.google.gson.annotations.SerializedName

class UsrDto(hanNm : String) {
    @SerializedName("hanNm")
    var hanNm : String = ""

    @SerializedName("engNm")
    var engNm : String = ""

    @SerializedName("mobile")
    var mobile : String = ""

    @SerializedName("deptNm")
    var deptNm : String = ""

    @SerializedName("fileHash")
    var fileHash : String = ""

    @SerializedName("usrId")
    var usrId : String = ""

    @SerializedName("birthYmd")
    var birthYmd : String = ""

    @SerializedName("jncmpYmd")
    var jncmpYmd : String = ""

    @SerializedName("mbrGd")
    var mbrGd : String = ""

    @SerializedName("email")
    var email : String = ""


    init {
        this.hanNm = hanNm
    }

}