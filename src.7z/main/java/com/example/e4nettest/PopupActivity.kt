package com.example.e4nettest

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import com.bumptech.glide.Glide
import com.example.e4nettest.databinding.ActivityPopupBinding

class PopupActivity(context: Context, model: UsrDto ) : Dialog(context) {

    var model = model

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //context.setTheme(android.R.style.Theme_Dialog)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        var binding = ActivityPopupBinding.inflate(layoutInflater)

        binding.usrInfoNm.text = model.hanNm
        binding.usrInfoBtDt.text = model.birthYmd
        binding.usrInfoJob.text = model.mbrGd
        binding.usrInfoEmail.text = model.email
        binding.usrInfoJoinDt.text = model.jncmpYmd

        Glide.with(binding.root.context)
            .load("https://ipfs.e4net.net/ipfs/"+ model.fileHash)
            .into(binding.usrInfoImg) // 이미지를 넣을 뷰


    setContentView(binding.root)


    //setContentView(R.layout.activity_popup)
    }
}