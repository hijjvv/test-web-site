package com.example.e4nettest

import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.net.CookieManager
import java.util.concurrent.TimeUnit

object RetrofitService {
    val httpClient = OkHttpClient.Builder()
        .cookieJar(JavaNetCookieJar(CookieManager()))
        .readTimeout(30, TimeUnit.SECONDS)
        .build()



    val retrofit = Retrofit.Builder()
        .baseUrl("https://ekep.e4net.net/api/")
        .addConverterFactory(GsonConverterFactory.create())
        .client(httpClient)
        .build()
}