package com.example.e4nettest

import android.app.AlertDialog
import android.content.Context
import android.content.Intent

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.e4nettest.databinding.ActivityMainBinding
import com.example.e4nettest.databinding.SideBarBinding
import com.example.e4nettest.databinding.UsrListBinding

class UsrInnnerListAdater (context: Context, val itemList: ArrayList<UsrDto>): RecyclerView.Adapter<UsrInnnerListAdater.Holder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val binding = UsrListBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return Holder(binding)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = itemList[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int {
        return itemList.size
    }

    inner class Holder(var binding: UsrListBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: UsrDto) {

            binding.model = item
            binding.hanNm.text = item.hanNm
            binding.engNm.text = "(" + item.usrId + ")"
            binding.mobile.text = item.mobile

            binding.root.setOnClickListener{
//               var intent  = Intent(binding.root.context, PopupActivity::class.java)
//                binding.root.context.startActivity(intent)
                PopupActivity(binding.root.context , binding.model!!).show()
            }



            Glide.with(this.itemView)
                .load("https://ipfs.e4net.net/ipfs/"+ item.fileHash)
                .into(binding.usrImg) // 이미지를 넣을 뷰
        }
    }

}